
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '商品',
    enableValidate: false
})

@Injectable()
export class DataGridComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'goodsName',
        name: "{{goodsName_28bdca83_zmdi}}",
        binding: 'goodsName',
        updateOn: 'blur',
        defaultI18nValue: '商品名称',
    })
    goodsName: FormControl;

    @NgFormControl({
        id: 'goodsCode',
        name: "{{goodsCode_7f38293d_qgha}}",
        binding: 'goodsCode',
        updateOn: 'blur',
        defaultI18nValue: '商品编号',
    })
    goodsCode: FormControl;

}