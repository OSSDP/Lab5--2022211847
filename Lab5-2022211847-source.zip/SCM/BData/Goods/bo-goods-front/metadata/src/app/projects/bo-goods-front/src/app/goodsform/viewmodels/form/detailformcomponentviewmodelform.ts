
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '商品',
    enableValidate: true
})

@Injectable()
export class DetailFormComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'goodsName_28bdca83_oc76',
        name: "{{goodsName_28bdca83_oc76}}",
        binding: 'goodsName',
        updateOn: 'blur',
        defaultI18nValue: '商品名称',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    goodsName: FormControl;

    @NgFormControl({
        id: 'goodsCode_7f38293d_5kr9',
        name: "{{goodsCode_7f38293d_5kr9}}",
        binding: 'goodsCode',
        updateOn: 'blur',
        defaultI18nValue: '商品编号',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    goodsCode: FormControl;

    @NgFormControl({
        id: 'specification_2d41423a_jrpw',
        name: "{{specification_2d41423a_jrpw}}",
        binding: 'specification',
        updateOn: 'blur',
        defaultI18nValue: '规格型号',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    specification: FormControl;

    @NgFormControl({
        id: 'category_e83fbfe0_a0wd',
        name: "{{category_e83fbfe0_a0wd}}",
        binding: 'category',
        updateOn: 'blur',
        defaultI18nValue: '分类名称',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    category: FormControl;

    @NgFormControl({
        id: 'price_c6c10ace_i5eg',
        name: "{{price_c6c10ace_i5eg}}",
        binding: 'price',
        updateOn: 'blur',
        defaultI18nValue: '单价',
    })
    price: FormControl;

    @NgFormControl({
        id: 'listNumber_6e39889b_qr92',
        name: "{{listNumber_6e39889b_qr92}}",
        binding: 'listNumber',
        updateOn: 'blur',
        defaultI18nValue: '上架数量',
    })
    listNumber: FormControl;

    @NgFormControl({
        id: 'remark_d0065a5e_s60p',
        name: "{{remark_d0065a5e_s60p}}",
        binding: 'remark',
        updateOn: 'blur',
        defaultI18nValue: '备注',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    remark: FormControl;

}