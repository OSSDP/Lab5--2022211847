import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var DetailFormComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DetailFormComponentViewmodelForm, _super);
    function DetailFormComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'goodsName_28bdca83_oc76',
            name: "{{goodsName_28bdca83_oc76}}",
            binding: 'goodsName',
            updateOn: 'blur',
            defaultI18nValue: '商品名称',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "goodsName", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'goodsCode_7f38293d_5kr9',
            name: "{{goodsCode_7f38293d_5kr9}}",
            binding: 'goodsCode',
            updateOn: 'blur',
            defaultI18nValue: '商品编号',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "goodsCode", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'specification_2d41423a_jrpw',
            name: "{{specification_2d41423a_jrpw}}",
            binding: 'specification',
            updateOn: 'blur',
            defaultI18nValue: '规格型号',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "specification", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'category_e83fbfe0_a0wd',
            name: "{{category_e83fbfe0_a0wd}}",
            binding: 'category',
            updateOn: 'blur',
            defaultI18nValue: '分类名称',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "category", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'price_c6c10ace_i5eg',
            name: "{{price_c6c10ace_i5eg}}",
            binding: 'price',
            updateOn: 'blur',
            defaultI18nValue: '单价',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "price", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'listNumber_6e39889b_qr92',
            name: "{{listNumber_6e39889b_qr92}}",
            binding: 'listNumber',
            updateOn: 'blur',
            defaultI18nValue: '上架数量',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "listNumber", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'remark_d0065a5e_s60p',
            name: "{{remark_d0065a5e_s60p}}",
            binding: 'remark',
            updateOn: 'blur',
            defaultI18nValue: '备注',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "remark", void 0);
    DetailFormComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '商品',
            enableValidate: true
        }),
        Injectable()
    ], DetailFormComponentViewmodelForm);
    return DetailFormComponentViewmodelForm;
}(Form));
export { DetailFormComponentViewmodelForm };
