import * as tslib_1 from "tslib";
import { Pipe, Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { of } from 'rxjs';
import { catchError, switchMap } from "rxjs/operators";
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
import { BasePathService } from '@farris/rtf';
export function createTranslateLoader(http, version) {
    var versionSuffix = "";
    if (version) {
        versionSuffix = "?v=" + version;
    }
    return new TranslateHttpLoader(http, BasePathService.convertPath('/apps/scm/om/web/bo-so-front/saleordercard/i18n/'), '.json' + versionSuffix);
}
export var lang = { "zh-CHS": { "root-component": "", "root-layout": "", "page-header": "", "header-nav": "", "header-title-container": "", "page-header-title": "", "title": "销售订单制单", "page-header-toolbar": "", "button-add": "新增", "button-edit": "编辑", "button-save": "保存", "button-cancel": "取消", "button-approve": "提交审批", "button-cancel-approve": "取消提交审批", "main-container": "", "like-card-container": "", "basic-form-component-ref": "", "detail-container": "", "detail-section": "", "Section/detail-section/mainTitle": "", "Section/detail-section/subTitle": "", "detail-tab": "", "orderitem-tab-page": "订单明细", "orderitem-component-ref": "", "orderitem-tab-toolbar": "", "orderitemAddButton": "新增", "orderitemRemoveButton": "删除", "plus-tab-page": "附件", "plus-component-ref": "", "plus-tab-toolbar": "", "plusAddButton": "新增", "plusRemoveButton": "删除", "basic-form-component": "", "basic-form-section": "", "Section/basic-form-section/mainTitle": "基本信息", "Section/basic-form-section/subTitle": "", "basic-form-layout": "", "59966a88-35a3-4229-8482-f42d595000a7": "基本信息", "FieldSet/59966a88-35a3-4229-8482-f42d595000a7/collapseText": "", "FieldSet/59966a88-35a3-4229-8482-f42d595000a7/expandText": "", "orderCode_f2d9e158_kgvz": "订单编号", "TextBox/orderCode_f2d9e158_kgvz/placeHolder": "", "merchant_Merchant_name_dc52b957_0e1v": "商户", "LookupEdit/merchant_Merchant_name_dc52b957_0e1v/placeHolder": "", "LookupEdit/merchant_Merchant_name_dc52b957_0e1v/dialogTitle": "", "orderTime_898df2fe_xjlg": "下单时间", "TextBox/orderTime_898df2fe_xjlg/placeHolder": "", "orderPerson_OrderPerson_name_2d1d302a_0aak": "下单人", "LookupEdit/orderPerson_OrderPerson_name_2d1d302a_0aak/placeHolder": "", "LookupEdit/orderPerson_OrderPerson_name_2d1d302a_0aak/dialogTitle": "", "billStatus_BillState_df94470c_t04q": "单据状态", "EnumField/billStatus_BillState_df94470c_t04q/placeHolder": "", "EnumField/billStatus_BillState_df94470c_t04q/enumData/Billing": "制单", "EnumField/billStatus_BillState_df94470c_t04q/enumData/SubmitApproval": "提交审批", "EnumField/billStatus_BillState_df94470c_t04q/enumData/Approved": "审批通过", "EnumField/billStatus_BillState_df94470c_t04q/enumData/ApprovalNotPassed": "审批不通过", "telephone_a1f41ba4_yxps": "联系电话", "TextBox/telephone_a1f41ba4_yxps/placeHolder": "", "orderState_8665667d_dfjn": "订单状态", "EnumField/orderState_8665667d_dfjn/placeHolder": "", "EnumField/orderState_8665667d_dfjn/enumData/Unshipped": "未发货", "EnumField/orderState_8665667d_dfjn/enumData/Shipped": "已发货", "remark_e5d2dfa9_cljr": "备注", "TextBox/remark_e5d2dfa9_cljr/placeHolder": "", "999b88aa-05f2-4baa-8aca-b44df208eb5c": "支付信息", "FieldSet/999b88aa-05f2-4baa-8aca-b44df208eb5c/collapseText": "", "FieldSet/999b88aa-05f2-4baa-8aca-b44df208eb5c/expandText": "", "payMethod_5e15710a_1pao": "支付方式", "EnumField/payMethod_5e15710a_1pao/placeHolder": "", "EnumField/payMethod_5e15710a_1pao/enumData/Cash": "现金", "EnumField/payMethod_5e15710a_1pao/enumData/Upay": "银联", "EnumField/payMethod_5e15710a_1pao/enumData/WeChat": "微信", "EnumField/payMethod_5e15710a_1pao/enumData/AliPay": "支付宝", "orderType_86c9e32c_ivwq": "订单类型", "TextBox/orderType_86c9e32c_ivwq/placeHolder": "", "totalPrice_a6bb5a5f_5ugx": "订单金额", "NumberSpinner/totalPrice_a6bb5a5f_5ugx/placeHolder": "", "orderitem-component": "", "orderitem-component-layout": "", "dataGrid_orderitem": "", "DataGrid/dataGrid_orderitem/lineNumberTitle": "", "DataGrid/dataGrid_orderitem/OperateEditButton": "编辑", "DataGrid/dataGrid_orderitem/OperateDeleteButton": "删除", "DataGrid/dataGrid_orderitem/OperateColumn": "操作", "goods_Goods_GoodsName_cd37eccb_m6h9": "商品名称", "GridField/goods_Goods_GoodsName_cd37eccb_m6h9/editor/goods_Goods_GoodsName_cd37eccb_bgad": "商品名称", "GridField/goods_Goods_GoodsName_cd37eccb_m6h9/editor/LookupEdit/goods_Goods_GoodsName_cd37eccb_bgad/placeHolder": "", "GridField/goods_Goods_GoodsName_cd37eccb_m6h9/editor/LookupEdit/goods_Goods_GoodsName_cd37eccb_bgad/dialogTitle": "", "goods_Goods_Specification_a9d828f8_of7o": "规格型号", "GridField/goods_Goods_Specification_a9d828f8_of7o/editor/goods_Goods_Specification_a9d828f8_jn7y": "规格型号", "GridField/goods_Goods_Specification_a9d828f8_of7o/editor/TextBox/goods_Goods_Specification_a9d828f8_jn7y/placeHolder": "", "quality_aad2548f_ijrt": "数量", "GridField/quality_aad2548f_ijrt/editor/quality_aad2548f_g2gf": "数量", "GridField/quality_aad2548f_ijrt/editor/NumberSpinner/quality_aad2548f_g2gf/placeHolder": "", "price_1a57e03c_wmqb": "标准单价", "GridField/price_1a57e03c_wmqb/editor/price_1a57e03c_47bs": "标准单价", "GridField/price_1a57e03c_wmqb/editor/NumberSpinner/price_1a57e03c_47bs/placeHolder": "", "actualPrice_ffcf39b2_qt08": "实际单价", "GridField/actualPrice_ffcf39b2_qt08/editor/actualPrice_ffcf39b2_oiwl": "实际单价", "GridField/actualPrice_ffcf39b2_qt08/editor/NumberSpinner/actualPrice_ffcf39b2_oiwl/placeHolder": "", "discountType_c9be5f52_qw4r": "折扣类型", "GridField/discountType_c9be5f52_qw4r/enumData/Dis": "折扣", "GridField/discountType_c9be5f52_qw4r/enumData/NoDIs": "无折扣", "discount_92ee9f2f_or2b": "折扣", "GridField/discount_92ee9f2f_or2b/editor/discount_92ee9f2f_dkwy": "折扣", "GridField/discount_92ee9f2f_or2b/editor/TextBox/discount_92ee9f2f_dkwy/placeHolder": "", "amount_9b7b1a84_vfjl": "结算金额", "GridField/amount_9b7b1a84_vfjl/editor/amount_9b7b1a84_luhv": "结算金额", "GridField/amount_9b7b1a84_vfjl/editor/NumberSpinner/amount_9b7b1a84_luhv/placeHolder": "", "plus-component": "", "plus-component-layout": "", "dataGrid_plus": "", "DataGrid/dataGrid_plus/lineNumberTitle": "", "DataGrid/dataGrid_plus/OperateEditButton": "编辑", "DataGrid/dataGrid_plus/OperateDeleteButton": "删除", "DataGrid/dataGrid_plus/OperateColumn": "操作", "fileInfo_FileInfo_Attachment_beda48ec_0lx6": "附件Id", "GridField/fileInfo_FileInfo_Attachment_beda48ec_0lx6/editor/fileInfo_FileInfo_Attachment_beda48ec_esnw": "附件Id", "GridField/fileInfo_FileInfo_Attachment_beda48ec_0lx6/editor/TextBox/fileInfo_FileInfo_Attachment_beda48ec_esnw/placeHolder": "", "fileInfo_FileInfo_FileName_fb0c4b5e_h66o": "附件名称", "GridField/fileInfo_FileInfo_FileName_fb0c4b5e_h66o/editor/fileInfo_FileInfo_FileName_fb0c4b5e_zlxk": "附件名称", "GridField/fileInfo_FileInfo_FileName_fb0c4b5e_h66o/editor/TextBox/fileInfo_FileInfo_FileName_fb0c4b5e_zlxk/placeHolder": "", "fileInfo_FileInfo_FileSize_bed6f51d_v9nr": "附件大小", "GridField/fileInfo_FileInfo_FileSize_bed6f51d_v9nr/editor/fileInfo_FileInfo_FileSize_bed6f51d_bamd": "附件大小", "GridField/fileInfo_FileInfo_FileSize_bed6f51d_v9nr/editor/NumberSpinner/fileInfo_FileInfo_FileSize_bed6f51d_bamd/placeHolder": "", "fileInfo_FileInfo_FileCreate_3e128aef_kbsh": "附件上传时间", "GridField/fileInfo_FileInfo_FileCreate_3e128aef_kbsh/editor/fileInfo_FileInfo_FileCreate_3e128aef_717z": "附件上传时间", "GridField/fileInfo_FileInfo_FileCreate_3e128aef_kbsh/editor/DateBox/fileInfo_FileInfo_FileCreate_3e128aef_717z/placeHolder": "" } };
var LangPipe = /** @class */ (function () {
    function LangPipe(translate, http) {
        this.translate = translate;
        this.http = http;
    }
    LangPipe.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangPipe = tslib_1.__decorate([
        Pipe({ name: 'lang' }),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], LangPipe);
    return LangPipe;
}());
export { LangPipe };
var SafeHtmlPipe = /** @class */ (function () {
    function SafeHtmlPipe(sanitizer) {
        this.sanitizer = sanitizer;
    }
    SafeHtmlPipe.prototype.transform = function (url) {
        if (!url) {
            url = "";
        }
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    };
    SafeHtmlPipe = tslib_1.__decorate([
        Pipe({ name: 'safeHtml' }),
        tslib_1.__metadata("design:paramtypes", [DomSanitizer])
    ], SafeHtmlPipe);
    return SafeHtmlPipe;
}());
export { SafeHtmlPipe };
var LangService = /** @class */ (function () {
    function LangService(translate) {
        this.translate = translate;
    }
    LangService.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangService.prototype.getCurrentLanguage = function () {
        return this.translate.currentLang;
    };
    LangService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService])
    ], LangService);
    return LangService;
}());
export { LangService };
var TranslateResolveService = /** @class */ (function () {
    function TranslateResolveService(translate, http) {
        this.translate = translate;
        this.http = http;
        translate.defaultLang = 'zh-CHS';
        translate.setTranslation('zh-CHS', lang['zh-CHS']);
    }
    TranslateResolveService.prototype.resolve = function (route, state) {
        var _this = this;
        var langCode = localStorage.getItem('languageCode');
        if (!langCode) {
            langCode = "zh-CHS";
        }
        if (langCode == "zh-CHS" || (this.translate.defaultLang === langCode && this.translate.currentLoader == createTranslateLoader(this.http, null))) {
            this.translate.setTranslation('zh-CHS', lang['zh-CHS']);
            return of(this.translate[langCode]);
        }
        else {
            var httpOb = this.http.get(BasePathService.getBasePath() + "/apps/scm/om/web/bo-so-front/version.json?v=" + new Date().getTime()).pipe(switchMap(function (data) {
                var currentVersion = null;
                if (data instanceof Array) {
                    var versionKey_1 = "saleordercard/" + langCode + ".json";
                    data.forEach(function (item) {
                        if (item.category == "i18n" && item.key == versionKey_1) {
                            currentVersion = item.value;
                        }
                    });
                }
                _this.translate.defaultLang = langCode;
                _this.translate.currentLang = langCode;
                _this.translate.currentLoader = createTranslateLoader(_this.http, currentVersion);
                var tran = _this.translate.getTranslation(langCode).pipe(catchError(function (err) {
                    console.error("read resource file failed,please check!!! " + err);
                    return of(err);
                }));
                return tran;
            }));
            return httpOb;
        }
    };
    TranslateResolveService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], TranslateResolveService);
    return TranslateResolveService;
}());
export { TranslateResolveService };
