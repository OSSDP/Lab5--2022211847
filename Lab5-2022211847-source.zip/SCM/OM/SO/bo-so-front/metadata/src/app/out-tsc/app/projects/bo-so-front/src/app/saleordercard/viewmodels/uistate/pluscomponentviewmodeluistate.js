import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { UIState } from '@farris/devkit';
var PlusComponentViewmodelUIState = /** @class */ (function (_super) {
    tslib_1.__extends(PlusComponentViewmodelUIState, _super);
    function PlusComponentViewmodelUIState() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    PlusComponentViewmodelUIState = tslib_1.__decorate([
        Injectable()
    ], PlusComponentViewmodelUIState);
    return PlusComponentViewmodelUIState;
}(UIState));
export { PlusComponentViewmodelUIState };
