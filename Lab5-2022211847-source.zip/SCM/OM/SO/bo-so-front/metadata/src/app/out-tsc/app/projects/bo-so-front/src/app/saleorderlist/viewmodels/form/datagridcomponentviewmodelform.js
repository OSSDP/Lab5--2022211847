import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var DataGridComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelForm, _super);
    function DataGridComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'billStatus.billState',
            name: "{{billStatus_BillState_50e3aa53_3sea}}",
            binding: 'billStatus.billState',
            updateOn: 'change',
            defaultI18nValue: '状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "billStatus_BillState", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'orderCode',
            name: "{{orderCode_86945490_15in}}",
            binding: 'orderCode',
            updateOn: 'blur',
            defaultI18nValue: '订单编号',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "orderCode", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'merchant.merchant_name',
            name: "{{merchant_Merchant_name_ca2fb712_oe0t}}",
            binding: 'merchant.merchant_name',
            updateOn: 'blur',
            defaultI18nValue: '商户',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "merchant_Merchant_name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'orderTime',
            name: "{{orderTime_d9062349_lu54}}",
            binding: 'orderTime',
            updateOn: 'blur',
            defaultI18nValue: '下单时间',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "orderTime", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'payMethod',
            name: "{{payMethod_0fc73a46_ogsf}}",
            binding: 'payMethod',
            updateOn: 'change',
            defaultI18nValue: '支付方式',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "payMethod", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'orderPerson.orderPerson_name',
            name: "{{orderPerson_OrderPerson_name_46cb53b8_bfb4}}",
            binding: 'orderPerson.orderPerson_name',
            updateOn: 'blur',
            defaultI18nValue: '下单人',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "orderPerson_OrderPerson_name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'orderState',
            name: "{{orderState_cd5e1d95_x4qs}}",
            binding: 'orderState',
            updateOn: 'change',
            defaultI18nValue: '订单状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "orderState", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'totalPrice',
            name: "{{totalPrice_c123bb96_yin6}}",
            binding: 'totalPrice',
            updateOn: 'blur',
            defaultI18nValue: '订单金额',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "totalPrice", void 0);
    DataGridComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '销售订单',
            enableValidate: false
        }),
        Injectable()
    ], DataGridComponentViewmodelForm);
    return DataGridComponentViewmodelForm;
}(Form));
export { DataGridComponentViewmodelForm };
