import * as tslib_1 from "tslib";
import { Entity, NgField, NgObject, NgEntity } from '@farris/devkit';
import { Goods4842Entity } from './goods4842entity';
var OrderItemEntity = /** @class */ (function (_super) {
    tslib_1.__extends(OrderItemEntity, _super);
    function OrderItemEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], OrderItemEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ParentID',
            dataField: 'parentID',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ParentID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], OrderItemEntity.prototype, "parentID", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Specification',
            dataField: 'specification',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Specification',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], OrderItemEntity.prototype, "specification", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Quality',
            dataField: 'quality',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'Quality',
        }),
        tslib_1.__metadata("design:type", Object)
    ], OrderItemEntity.prototype, "quality", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Price',
            dataField: 'price',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'Price',
        }),
        tslib_1.__metadata("design:type", Object)
    ], OrderItemEntity.prototype, "price", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ActualPrice',
            dataField: 'actualPrice',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'ActualPrice',
        }),
        tslib_1.__metadata("design:type", Object)
    ], OrderItemEntity.prototype, "actualPrice", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'DiscountType',
            dataField: 'discountType',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'Dis',
            path: 'DiscountType',
        }),
        tslib_1.__metadata("design:type", Object)
    ], OrderItemEntity.prototype, "discountType", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Discount',
            dataField: 'discount',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Discount',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [10],
                    message: '最大长度为10',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], OrderItemEntity.prototype, "discount", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Amount',
            dataField: 'amount',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'Amount',
        }),
        tslib_1.__metadata("design:type", Object)
    ], OrderItemEntity.prototype, "amount", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Remark',
            dataField: 'remark',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Remark',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [100],
                    message: '最大长度为100',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], OrderItemEntity.prototype, "remark", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'goods',
            originalDataField: 'Goods',
            type: Goods4842Entity
        }),
        tslib_1.__metadata("design:type", Goods4842Entity)
    ], OrderItemEntity.prototype, "goods", void 0);
    OrderItemEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "OrderItem",
            nodeCode: "orderItems"
        })
    ], OrderItemEntity);
    return OrderItemEntity;
}(Entity));
export { OrderItemEntity };
