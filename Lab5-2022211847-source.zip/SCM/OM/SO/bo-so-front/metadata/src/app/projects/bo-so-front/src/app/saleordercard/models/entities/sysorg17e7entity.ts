
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity, NgEntity } from '@farris/devkit';

@NgEntity({
    originalCode: "Merchant",
    nodeCode: "merchant"
})
export class SysOrg17e7Entity extends Entity {

    @NgField({
        originalDataField: 'Merchant',
        dataField: 'merchant',
        primary: true,
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Merchant.Merchant',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    merchant: string;

    @NgField({
        originalDataField: 'name',
        dataField: 'merchant_name',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Merchant.Merchant_name',

        validRules: [
            {
                type: 'maxLength',
                constraints: [100],
                message: '最大长度为100',
            }
        ]
    })
    merchant_name: string;

}