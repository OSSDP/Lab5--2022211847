import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var SysOrg17e7Entity = /** @class */ (function (_super) {
    tslib_1.__extends(SysOrg17e7Entity, _super);
    function SysOrg17e7Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Merchant',
            dataField: 'merchant',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Merchant.Merchant',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SysOrg17e7Entity.prototype, "merchant", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'name',
            dataField: 'merchant_name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Merchant.Merchant_name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [100],
                    message: '最大长度为100',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SysOrg17e7Entity.prototype, "merchant_name", void 0);
    SysOrg17e7Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "Merchant",
            nodeCode: "merchant"
        })
    ], SysOrg17e7Entity);
    return SysOrg17e7Entity;
}(Entity));
export { SysOrg17e7Entity };
