import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var BillState50e3Entity = /** @class */ (function (_super) {
    tslib_1.__extends(BillState50e3Entity, _super);
    function BillState50e3Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'BillState',
            dataField: 'billState',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'Billing',
            path: 'BillStatus.BillState',
        }),
        tslib_1.__metadata("design:type", Object)
    ], BillState50e3Entity.prototype, "billState", void 0);
    BillState50e3Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "BillStatus",
            nodeCode: "billStatus"
        })
    ], BillState50e3Entity);
    return BillState50e3Entity;
}(Entity));
export { BillState50e3Entity };
