
import { Injectable } from '@angular/core';
import { ViewModel, NgCommand } from '@farris/devkit';
import { Observable } from 'rxjs';

@Injectable()
export class PlusComponentViewmodel extends ViewModel {
    public bindingPath = '/pluss';
    // farrisDataGrid列集合定义 在对应component中赋值
    public dataGrid_plusColumns:any;
    // datGrid 列集合名称 用以bindData使用
    public dataGridColumnsName:string;

    public dom = {
  "dataGrid_plus": {
    "type": "DataGrid",
    "resourceId": "dataGrid_plus",
    "visible": {
      "useQuote": false,
      "isExpression": false,
      "value": true
    },
    "id": "dataGrid_plus",
    "size": {},
    "readonly": {
      "useQuote": false,
      "isExpression": false,
      "value": false
    },
    "fields": [
      {
        "type": "GridField",
        "resourceId": "fileInfo_FileInfo_Attachment_beda48ec_0lx6",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "fileInfo_FileInfo_Attachment_beda48ec_0lx6",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "fileInfo_FileInfo_Attachment",
          "fullPath": "FileInfo.FileInfo_Attachment",
          "isExpression": false,
          "value": "fileInfo_FileInfo_Attachment"
        },
        "dataField": "fileInfo.fileInfo_Attachment",
        "dataType": "string",
        "multiLanguage": false,
        "caption": "附件Id",
        "editor": {
          "type": "TextBox",
          "isTextArea": true,
          "resourceId": "fileInfo_FileInfo_Attachment_beda48ec_esnw",
          "defaultI18nValue": "附件Id",
          "visible": {
            "useQuote": false,
            "isExpression": false,
            "value": true
          },
          "id": "fileInfo_FileInfo_Attachment_beda48ec_esnw",
          "size": {},
          "readonly": {
            "useQuote": false,
            "isExpression": false,
            "value": false
          },
          "binding": {
            "type": "Form",
            "path": "fileInfo_FileInfo_Attachment",
            "isExpression": false,
            "value": "fileInfo_FileInfo_Attachment"
          },
          "disable": false,
          "maxLength": 36,
          "isPassword": false,
          "enableViewPassword": false
        },
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "fileInfo_FileInfo_FileName_fb0c4b5e_h66o",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "fileInfo_FileInfo_FileName_fb0c4b5e_h66o",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "fileInfo_FileInfo_FileName",
          "fullPath": "FileInfo.FileInfo_FileName",
          "isExpression": false,
          "value": "fileInfo_FileInfo_FileName"
        },
        "dataField": "fileInfo.fileInfo_FileName",
        "dataType": "string",
        "multiLanguage": false,
        "caption": "附件名称",
        "editor": {
          "type": "TextBox",
          "isTextArea": true,
          "resourceId": "fileInfo_FileInfo_FileName_fb0c4b5e_zlxk",
          "defaultI18nValue": "附件名称",
          "visible": {
            "useQuote": false,
            "isExpression": false,
            "value": true
          },
          "id": "fileInfo_FileInfo_FileName_fb0c4b5e_zlxk",
          "size": {},
          "readonly": {
            "useQuote": false,
            "isExpression": false,
            "value": false
          },
          "binding": {
            "type": "Form",
            "path": "fileInfo_FileInfo_FileName",
            "isExpression": false,
            "value": "fileInfo_FileInfo_FileName"
          },
          "disable": false,
          "maxLength": 36,
          "isPassword": false,
          "enableViewPassword": false
        },
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "fileInfo_FileInfo_FileSize_bed6f51d_v9nr",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "fileInfo_FileInfo_FileSize_bed6f51d_v9nr",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "fileInfo_FileInfo_FileSize",
          "fullPath": "FileInfo.FileInfo_FileSize",
          "isExpression": false,
          "value": "fileInfo_FileInfo_FileSize"
        },
        "dataField": "fileInfo.fileInfo_FileSize",
        "dataType": "number",
        "multiLanguage": false,
        "caption": "附件大小",
        "editor": {
          "type": "FarrisNumberSpinner",
          "isTextArea": true,
          "resourceId": "fileInfo_FileInfo_FileSize_bed6f51d_bamd",
          "defaultI18nValue": "附件大小",
          "visible": {
            "useQuote": false,
            "isExpression": false,
            "value": true
          },
          "id": "fileInfo_FileInfo_FileSize_bed6f51d_bamd",
          "size": {},
          "readonly": {
            "useQuote": false,
            "isExpression": false,
            "value": false
          },
          "binding": {
            "type": "Form",
            "path": "fileInfo_FileInfo_FileSize",
            "isExpression": false,
            "value": "fileInfo_FileInfo_FileSize"
          },
          "disable": false,
          "step": 1,
          "useThousands": true,
          "textAlign": "left",
          "precision": 2
        },
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "number",
          "precision": 2,
          "thousand": ",",
          "decimal": "."
        }
      },
      {
        "type": "GridField",
        "resourceId": "fileInfo_FileInfo_FileCreate_3e128aef_kbsh",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "fileInfo_FileInfo_FileCreate_3e128aef_kbsh",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "fileInfo_FileInfo_FileCreate",
          "fullPath": "FileInfo.FileInfo_FileCreate",
          "isExpression": false,
          "value": "fileInfo_FileInfo_FileCreate"
        },
        "dataField": "fileInfo.fileInfo_FileCreate",
        "dataType": "datetime",
        "multiLanguage": false,
        "caption": "附件上传时间",
        "editor": {
          "type": "EditableField",
          "disable": false,
          "editable": true,
          "dateRange": false,
          "showTime": true,
          "title": "附件上传时间",
          "showType": 1,
          "locale": "zh-cn",
          "dateFormat": "yyyy-MM-dd HH:mm:ss",
          "placeHolder": "",
          "linkedLabelEnabled": false,
          "disableDates": [],
          "returnType": "Date",
          "useDefault": false,
          "showWeekNumbers": false,
          "dateRangeDatesDelimiter": "~",
          "shortcuts": [],
          "returnFormat": "yyyy-MM-dd HH:mm:ss",
          "titleWidth": null,
          "localization": false,
          "isTextArea": true,
          "resourceId": "fileInfo_FileInfo_FileCreate_3e128aef_717z",
          "defaultI18nValue": "附件上传时间",
          "visible": {
            "useQuote": false,
            "isExpression": false,
            "value": true
          },
          "id": "fileInfo_FileInfo_FileCreate_3e128aef_717z",
          "size": {},
          "readonly": {
            "useQuote": false,
            "isExpression": false,
            "value": false
          },
          "binding": {
            "type": "Form",
            "path": "fileInfo_FileInfo_FileCreate",
            "isExpression": false,
            "value": "fileInfo_FileInfo_FileCreate"
          }
        },
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "date",
          "dateFormat": "yyyy-MM-dd HH:mm:ss"
        }
      }
    ],
    "multiSelect": false,
    "editable": "viewModel.stateMachine['editable']",
    "showLineNumber": false,
    "lineNumberTitle": "#",
    "groupTotalText": "Total",
    "filterable": false,
    "groupable": false,
    "rowClass": ""
  }
};
    @NgCommand({
        name: 'plusAddItem1',
        params: {
        }
    })
    public plusAddItem1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'plusRemoveItem1',
        params: {
            id: '{DATA~/#{plus-component}/pluss/id}'
        },
        paramDescriptions: {
            id: { type: 'string' }
        }
    })
    public plusRemoveItem1(commandParam?: any): Observable<any> { return; }

}