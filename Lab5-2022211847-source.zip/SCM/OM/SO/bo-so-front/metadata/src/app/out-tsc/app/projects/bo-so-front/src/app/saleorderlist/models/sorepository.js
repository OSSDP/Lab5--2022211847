import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { SOEntity } from './entities/soentity';
import { SOProxy } from './soproxy';
var SORepository = /** @class */ (function (_super) {
    tslib_1.__extends(SORepository, _super);
    function SORepository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'SORepository';
        _this.paginationInfo = {
            SOEntity: {
                pageSize: 20,
            }
        };
        _this.proxy = injector.get(SOProxy, null);
        return _this;
    }
    SORepository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/scm/om/v1.0/saleorderlist_frm',
            entityType: SOEntity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], SORepository);
    return SORepository;
}(BefRepository));
export { SORepository };
