
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '销售订单',
    enableValidate: false
})

@Injectable()
export class DataGridComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'billStatus.billState',
        name: "{{billStatus_BillState_50e3aa53_3sea}}",
        binding: 'billStatus.billState',
        updateOn: 'change',
        defaultI18nValue: '状态',
    })
    billStatus_BillState: FormControl;

    @NgFormControl({
        id: 'orderCode',
        name: "{{orderCode_86945490_15in}}",
        binding: 'orderCode',
        updateOn: 'blur',
        defaultI18nValue: '订单编号',
    })
    orderCode: FormControl;

    @NgFormControl({
        id: 'merchant.merchant_name',
        name: "{{merchant_Merchant_name_ca2fb712_oe0t}}",
        binding: 'merchant.merchant_name',
        updateOn: 'blur',
        defaultI18nValue: '商户',
    })
    merchant_Merchant_name: FormControl;

    @NgFormControl({
        id: 'orderTime',
        name: "{{orderTime_d9062349_lu54}}",
        binding: 'orderTime',
        updateOn: 'blur',
        defaultI18nValue: '下单时间',
    })
    orderTime: FormControl;

    @NgFormControl({
        id: 'payMethod',
        name: "{{payMethod_0fc73a46_ogsf}}",
        binding: 'payMethod',
        updateOn: 'change',
        defaultI18nValue: '支付方式',
    })
    payMethod: FormControl;

    @NgFormControl({
        id: 'orderPerson.orderPerson_name',
        name: "{{orderPerson_OrderPerson_name_46cb53b8_bfb4}}",
        binding: 'orderPerson.orderPerson_name',
        updateOn: 'blur',
        defaultI18nValue: '下单人',
    })
    orderPerson_OrderPerson_name: FormControl;

    @NgFormControl({
        id: 'orderState',
        name: "{{orderState_cd5e1d95_x4qs}}",
        binding: 'orderState',
        updateOn: 'change',
        defaultI18nValue: '订单状态',
    })
    orderState: FormControl;

    @NgFormControl({
        id: 'totalPrice',
        name: "{{totalPrice_c123bb96_yin6}}",
        binding: 'totalPrice',
        updateOn: 'blur',
        defaultI18nValue: '订单金额',
    })
    totalPrice: FormControl;

}