
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '附件',
    enableValidate: true
})

@Injectable()
export class PlusComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'fileInfo.fileInfo_Attachment',
        name: "{{fileInfo_FileInfo_Attachment_beda48ec_0lx6}}",
        binding: 'fileInfo.fileInfo_Attachment',
        updateOn: 'blur',
        defaultI18nValue: '附件Id',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    fileInfo_FileInfo_Attachment: FormControl;

    @NgFormControl({
        id: 'fileInfo.fileInfo_FileName',
        name: "{{fileInfo_FileInfo_FileName_fb0c4b5e_h66o}}",
        binding: 'fileInfo.fileInfo_FileName',
        updateOn: 'blur',
        defaultI18nValue: '附件名称',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    fileInfo_FileInfo_FileName: FormControl;

    @NgFormControl({
        id: 'fileInfo.fileInfo_FileSize',
        name: "{{fileInfo_FileInfo_FileSize_bed6f51d_v9nr}}",
        binding: 'fileInfo.fileInfo_FileSize',
        updateOn: 'blur',
        defaultI18nValue: '附件大小',
        validRules: [
            {
                type: 'maxValue',
                constraints: [1.7976931348623157e+308],
            },
            {
                type: 'minValue',
                constraints: [-1.7976931348623157e+308],
            }
        ]
    })
    fileInfo_FileInfo_FileSize: FormControl;

    @NgFormControl({
        id: 'fileInfo.fileInfo_FileCreate',
        name: "{{fileInfo_FileInfo_FileCreate_3e128aef_kbsh}}",
        binding: 'fileInfo.fileInfo_FileCreate',
        updateOn: 'blur',
        valueConverter: new DateConverter('yyyy-MM-dd'),
        defaultI18nValue: '附件上传时间',
    })
    fileInfo_FileInfo_FileCreate: FormControl;

}