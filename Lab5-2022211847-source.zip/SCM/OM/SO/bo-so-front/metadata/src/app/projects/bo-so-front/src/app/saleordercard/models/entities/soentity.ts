
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity, NgEntity } from '@farris/devkit';
import { OrderItemEntity } from './orderitementity';
import { PlusEntity } from './plusentity';
import { BillStateDf94Entity } from './billstatedf94entity';
import { ProcessInstanceEcEdEntity } from './processinstanceecedentity';
import { SysOrg17e7Entity } from './sysorg17e7entity';
import { SysOrg5ffbEntity } from './sysorg5ffbentity';

@NgEntity({
    originalCode: "SO",
    nodeCode: "sos"
})
export class SOEntity extends Entity {

    @NgField({
        originalDataField: 'ID',
        dataField: 'id',
        primary: true,
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ID',

        validRules: [
            {
                type: 'required',
                constraints: [true],
            },
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    id: string;

    @NgField({
        originalDataField: 'Version',
        dataField: 'version',
        originalDataFieldType: 'DateTime',
        initValue: '0001-01-01T00:00:00',
        path: 'Version',
        enableTimeZone: true,
    })
    version: string;

    @NgField({
        originalDataField: 'OrderCode',
        dataField: 'orderCode',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'OrderCode',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    orderCode: string;

    @NgField({
        originalDataField: 'OrderTime',
        dataField: 'orderTime',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'OrderTime',

        validRules: [
            {
                type: 'maxLength',
                constraints: [30],
                message: '最大长度为30',
            }
        ]
    })
    orderTime: string;

    @NgField({
        originalDataField: 'PayMethod',
        dataField: 'payMethod',
        originalDataFieldType: 'Enum',
        defaultValue: '',
        initValue: 'Cash',
        path: 'PayMethod',
    })
    payMethod: any;

    @NgField({
        originalDataField: 'OrderType',
        dataField: 'orderType',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'OrderType',

        validRules: [
            {
                type: 'maxLength',
                constraints: [20],
                message: '最大长度为20',
            }
        ]
    })
    orderType: string;

    @NgField({
        originalDataField: 'Telephone',
        dataField: 'telephone',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Telephone',

        validRules: [
            {
                type: 'maxLength',
                constraints: [20],
                message: '最大长度为20',
            }
        ]
    })
    telephone: string;

    @NgField({
        originalDataField: 'OrderState',
        dataField: 'orderState',
        originalDataFieldType: 'Enum',
        defaultValue: '',
        initValue: 'Unshipped',
        path: 'OrderState',
    })
    orderState: any;

    @NgField({
        originalDataField: 'Remark',
        dataField: 'remark',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Remark',

        validRules: [
            {
                type: 'maxLength',
                constraints: [100],
                message: '最大长度为100',
            }
        ]
    })
    remark: string;

    @NgField({
        originalDataField: 'TotalPrice',
        dataField: 'totalPrice',
        originalDataFieldType: 'Number',
        initValue: 0,
        path: 'TotalPrice',
    })
    totalPrice: any;

    @NgList({
        dataField: 'orderItems',
        originalDataField: '',
        type: OrderItemEntity

    })

    orderItems: EntityList<OrderItemEntity>;
    @NgList({
        dataField: 'pluss',
        originalDataField: '',
        type: PlusEntity

    })

    pluss: EntityList<PlusEntity>;
    @NgObject({
        dataField: 'billStatus',
        originalDataField: 'BillStatus',
        type: BillStateDf94Entity
    })
    billStatus: BillStateDf94Entity;
    @NgObject({
        dataField: 'processInstance',
        originalDataField: 'ProcessInstance',
        type: ProcessInstanceEcEdEntity
    })
    processInstance: ProcessInstanceEcEdEntity;
    @NgObject({
        dataField: 'merchant',
        originalDataField: 'Merchant',
        type: SysOrg17e7Entity
    })
    merchant: SysOrg17e7Entity;
    @NgObject({
        dataField: 'orderPerson',
        originalDataField: 'OrderPerson',
        type: SysOrg5ffbEntity
    })
    orderPerson: SysOrg5ffbEntity;
}