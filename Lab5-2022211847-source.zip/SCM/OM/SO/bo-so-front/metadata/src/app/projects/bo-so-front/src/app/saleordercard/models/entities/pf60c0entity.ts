
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity, NgEntity } from '@farris/devkit';

@NgEntity({
    originalCode: "FileInfo",
    nodeCode: "fileInfo"
})
export class PF60c0Entity extends Entity {

    @NgField({
        originalDataField: 'FileInfo',
        dataField: 'fileInfo',
        primary: true,
        originalDataFieldType: 'String',
        initValue: '',
        path: 'FileInfo.FileInfo',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    fileInfo: string;

    @NgField({
        originalDataField: 'Attachment',
        dataField: 'fileInfo_Attachment',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'FileInfo.FileInfo_Attachment',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    fileInfo_Attachment: string;

    @NgField({
        originalDataField: 'FileName',
        dataField: 'fileInfo_FileName',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'FileInfo.FileInfo_FileName',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    fileInfo_FileName: string;

    @NgField({
        originalDataField: 'FileSize',
        dataField: 'fileInfo_FileSize',
        originalDataFieldType: 'Number',
        initValue: 0,
        path: 'FileInfo.FileInfo_FileSize',
    })
    fileInfo_FileSize: any;

    @NgField({
        originalDataField: 'FileCreate',
        dataField: 'fileInfo_FileCreate',
        originalDataFieldType: 'DateTime',
        initValue: '0001-01-01T00:00:00',
        path: 'FileInfo.FileInfo_FileCreate',
        enableTimeZone: true,
    })
    fileInfo_FileCreate: string;

}