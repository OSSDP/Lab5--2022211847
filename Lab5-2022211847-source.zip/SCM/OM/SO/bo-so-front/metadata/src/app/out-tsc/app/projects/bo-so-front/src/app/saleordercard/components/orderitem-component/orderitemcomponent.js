import * as tslib_1 from "tslib";
import { Component, Injector, ViewChild, HostBinding, ElementRef } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Form, FrameComponent, FARRIS_DEVKIT_FRAME_PROVIDERS, ViewModel, COMMAND_HANDLERS_TOKEN, FRAME_ID, BindingData, Repository, UIState, EXCEPTION_HANDLER, NAMESPACE } from '@farris/devkit';
import { FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS } from '@farris/command-services';
import { KeybindingService } from '@farris/command-services';
import { ActivatedRoute, Router } from '@angular/router';
import { FrmI18nSettingService } from '@gsp-sys/rtf-common';
import { DomSanitizer } from '@angular/platform-browser';
import { FocusInvalidService } from '@farris/command-services';
import { EditorTypes } from '@farris/ui-datagrid-editors';
import { DatagridComponent, GRID_SETTINGS_HTTP } from '@farris/ui-datagrid';
import { CommonUtils } from '@farris/ui-common';
import { BefLookupRestService, DefaultComboHttpService } from '@farris/bef';
import { ServerSideToken } from '@farris/ui-lookup';
import { ComboServerSideToken } from '@farris/ui-combo-list';
import { WizardService } from '@farris/ui-wizard';
import { LocalizationService } from "@farris/command-services";
import { OrderitemComponentViewmodel } from '../../viewmodels/orderitemcomponentviewmodel';
import { SORepository } from '../../models/sorepository';
import { LangService } from '../../lang/lang-pipe';
import { OrderitemComponentViewmodelForm } from '../../viewmodels/form/orderitemcomponentviewmodelform';
import { OrderitemComponentViewmodelUIState } from '../../viewmodels/uistate/orderitemcomponentviewmodeluistate';
import { orderitemAddItem1Handler } from '../../viewmodels/handlers/orderitemadditem1handler';
import { orderitemRemoveItem1Handler } from '../../viewmodels/handlers/orderitemremoveitem1handler';
var OrderitemComponent = /** @class */ (function (_super) {
    tslib_1.__extends(OrderitemComponent, _super);
    function OrderitemComponent(wizardSer, keybindingService, langService, route, router, rootElement, localizationService, frmI18nSettingService, focusInvalidService, farrisGridUtils, sanitizer, injector) {
        var _this = _super.call(this, injector) || this;
        _this.wizardSer = wizardSer;
        _this.keybindingService = keybindingService;
        _this.langService = langService;
        _this.route = route;
        _this.router = router;
        _this.rootElement = rootElement;
        _this.localizationService = localizationService;
        _this.frmI18nSettingService = frmI18nSettingService;
        _this.focusInvalidService = focusInvalidService;
        _this.farrisGridUtils = farrisGridUtils;
        _this.sanitizer = sanitizer;
        _this.injector = injector;
        _this.dataGrid_orderitemColumns = [];
        _this.cls = 'f-struct-is-subgrid ';
        _this.lang = "";
        _this.size = {};
        _this.enabledLanguageList = [];
        _this.tabsToolbarStates = new BehaviorSubject({});
        _this.tabsToolbarVisibleStates = new BehaviorSubject({});
        _this.dataGrid_orderitemlineNumberTitle = _this.langService.transform("DataGrid/dataGrid_orderitem/lineNumberTitle", _this.lang, "");
        _this.lang = localStorage.getItem('languageCode') || "zh-CHS";
        _this.viewModel.verifycationChanged.subscribe(function (verifyInformations) {
            _this.focusInvalidService.focusGridCell(verifyInformations, _this.dataGrid_orderitemDataGrid);
        });
        if (_this.frmI18nSettingService) {
            var i18nSetting = _this.frmI18nSettingService.getSetting();
            if (i18nSetting && i18nSetting.languages && i18nSetting.languages.length > 0) {
                i18nSetting.languages.forEach(function (item) {
                    _this.enabledLanguageList.push({
                        code: item.code,
                        name: item.name
                    });
                });
            }
            else {
                console.warn("get current enable languages is null. if this occurs,please ensure the form into the framework.");
                _this.enabledLanguageList.push({ "code": "en", "name": "English" });
                _this.enabledLanguageList.push({ "code": "zh-CHS", "name": "中文简体" });
            }
        }
        return _this;
    }
    OrderitemComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.keybindingService) {
            this.viewModel.keybindingMap.forEach(function (keyBinding, method) {
                _this.keybindingService.register(keyBinding, function () {
                    return _this.viewModel[method]();
                });
            });
        }
        this.dataGrid_orderitemColumns = [
            [
                {
                    id: 'goods_Goods_GoodsName_cd37eccb_m6h9',
                    field: 'goods.goods_GoodsName',
                    width: 120,
                    title: this.langService.transform("goods_Goods_GoodsName_cd37eccb_m6h9", this.lang, "商品名称"),
                    dataType: 'string',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.LOOKUP,
                        options: {
                            "type": 'EditorTypes.LOOKUP',
                            "uri": 'OrderItem.goods_Goods_GoodsName',
                            "readonly": false,
                            "idField": 'id',
                            "singleSelect": true,
                            "textField": 'goodsName',
                            "valueField": 'goodsName',
                            "pagination": null,
                            "pageSize": 20,
                            "pageIndex": null,
                            "displayType": 'List',
                            "mapFields": { 'id': 'goods.goods', 'goodsName': 'goods.goods_GoodsName', 'specification': 'goods.goods_Specification', 'price': 'price' },
                            "expandLevel": -1,
                            "showNavigation": true,
                            "cascadeStatus": 'enable',
                            "multipleChoiceSeparator": ",",
                            "useNewLayout": false,
                            "enableMultiFieldSearch": false,
                            "navTreeToList": false,
                            "treeToList": false,
                            "editable": false,
                            "enableCascade": false,
                            "showSelected": false,
                            "quickSelect": {
                                "enable": false,
                                "showItemsCount": 10,
                                "showMore": true
                            },
                            "useFavorite": true,
                            "enableFullTree": false,
                            "enableClear": true,
                            "loadTreeDataType": 'default',
                            "useTip": false,
                            "selectFirstInNav": false,
                            "loadDataWhenOpen": true,
                            "title": this.langService.transform("GridField/goods_Goods_GoodsName_cd37eccb_m6h9/editor/LookupEdit/goods_Goods_GoodsName_cd37eccb_bgad/dialogTitle", this.lang, ""),
                            "nosearch": false,
                            "context": {
                                "enableExtendLoadMethod": true
                            },
                            "isRecordSize": false,
                            "viewType": 'text'
                        }
                    },
                    sortable: true,
                    validators: [{ "type": "required", "message": "该字段不能为空！" }],
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: {}
                },
                {
                    id: 'goods_Goods_Specification_a9d828f8_of7o',
                    field: 'goods.goods_Specification',
                    width: 120,
                    title: this.langService.transform("goods_Goods_Specification_a9d828f8_of7o", this.lang, "规格型号"),
                    dataType: 'string',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.TEXTBOX,
                        options: { "id": "goods_Goods_Specification_a9d828f8_jn7y", "title": "规格型号", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.TEXTBOX", "isPassword": false, "maxLength": 36 }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: true,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: {}
                },
                {
                    id: 'quality_aad2548f_ijrt',
                    field: 'quality',
                    width: 120,
                    title: this.langService.transform("quality_aad2548f_ijrt", this.lang, "数量"),
                    dataType: 'number',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.NUMBERBOX,
                        options: { "id": "quality_aad2548f_g2gf", "title": "数量", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.NUMBERBOX", "precision": 0, "step": 1, "canNull": true, "bigNumber": false, "showButton": true, "showZero": true }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: { "type": "number", "options": { "precision": 0, "thousand": ",", "decimal": "." } }
                },
                {
                    id: 'price_1a57e03c_wmqb',
                    field: 'price',
                    width: 120,
                    title: this.langService.transform("price_1a57e03c_wmqb", this.lang, "标准单价"),
                    dataType: 'number',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.NUMBERBOX,
                        options: { "id": "price_1a57e03c_47bs", "title": "标准单价", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.NUMBERBOX", "precision": 2, "step": 1, "canNull": true, "bigNumber": false, "showButton": true, "showZero": true }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: { "type": "number", "options": { "precision": 2, "thousand": ",", "decimal": "." } }
                },
                {
                    id: 'actualPrice_ffcf39b2_qt08',
                    field: 'actualPrice',
                    width: 120,
                    title: this.langService.transform("actualPrice_ffcf39b2_qt08", this.lang, "实际单价"),
                    dataType: 'number',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.NUMBERBOX,
                        options: { "id": "actualPrice_ffcf39b2_oiwl", "title": "实际单价", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.NUMBERBOX", "precision": 2, "step": 1, "canNull": true, "bigNumber": false, "showButton": true, "showZero": true }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: { "type": "number", "options": { "precision": 2, "thousand": ",", "decimal": "." } }
                },
                {
                    id: 'discountType_c9be5f52_qw4r',
                    field: 'discountType',
                    width: 120,
                    title: this.langService.transform("discountType_c9be5f52_qw4r", this.lang, "折扣类型"),
                    dataType: 'enum',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.COMBOLIST,
                        options: { "id": "discountType_c9be5f52_25o9", "title": "折扣类型", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.COMBOLIST", "editable": false, "idField": "value", "enableClear": false, "textField": "name", "nosearch": false, "maxLength": null, "uri": "", "multiSelect": false, "data": [{ "value": "Dis", "name": this.langService.transform("GridField/discountType_c9be5f52_qw4r/enumData/Dis", this.lang, "折扣"), "disabled": false }, { "value": "NoDIs", "name": this.langService.transform("GridField/discountType_c9be5f52_qw4r/enumData/NoDIs", this.lang, "无折扣"), "disabled": false }], "autoWidth": true, "showDisabledItem": true }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: {
                        "type": "enum",
                        "options": {
                            "valueField": "value",
                            "textField": "name",
                            "data": [
                                {
                                    "value": "Dis",
                                    "name": this.langService.transform("GridField/discountType_c9be5f52_qw4r/enumData/Dis", this.lang, "折扣")
                                },
                                {
                                    "value": "NoDIs",
                                    "name": this.langService.transform("GridField/discountType_c9be5f52_qw4r/enumData/NoDIs", this.lang, "无折扣")
                                }
                            ]
                        }
                    }
                },
                {
                    id: 'discount_92ee9f2f_or2b',
                    field: 'discount',
                    width: 120,
                    title: this.langService.transform("discount_92ee9f2f_or2b", this.lang, "折扣"),
                    dataType: 'string',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.TEXTBOX,
                        options: { "id": "discount_92ee9f2f_dkwy", "title": "折扣", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.TEXTBOX", "isPassword": false, "maxLength": 10 }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: {}
                },
                {
                    id: 'amount_9b7b1a84_vfjl',
                    field: 'amount',
                    width: 120,
                    title: this.langService.transform("amount_9b7b1a84_vfjl", this.lang, "结算金额"),
                    dataType: 'number',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.NUMBERBOX,
                        options: { "id": "amount_9b7b1a84_luhv", "title": "结算金额", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.NUMBERBOX", "precision": 2, "step": 1, "canNull": true, "bigNumber": false, "showButton": true, "showZero": true }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: { "type": "number", "options": { "precision": 2, "thousand": ",", "decimal": "." } }
                }
            ]
        ];
        this.viewModel.dataGrid_orderitemColumns = this.dataGrid_orderitemColumns;
        this.viewModel.dataGridColumnsName = "dataGrid_orderitemColumns";
        this.onFormLoad();
    };
    OrderitemComponent.prototype.ngAfterViewInit = function () {
    };
    OrderitemComponent.prototype.ngOnDestroy = function () {
        // 增加表单的自我销毁
        this.context.dispose && this.context.dispose();
        this.context = null;
        this.subscription = null;
        this.declaration = null;
        this.wizardSer = null;
        this.keybindingService = null;
        this.langService = null;
        this.route = null;
        this.router = null;
        this.rootElement = null;
        this.localizationService = null;
        this.frmI18nSettingService = null;
        this.focusInvalidService = null;
        this.farrisGridUtils = null;
        this.sanitizer = null;
        this.injector = null;
        this.enabledLanguageList = [];
    };
    OrderitemComponent.prototype.handleSizeChange = function (size) {
        this.size = size;
    };
    OrderitemComponent.prototype.onFormLoad = function () {
    };
    tslib_1.__decorate([
        ViewChild('dataGrid_orderitemDataGrid'),
        tslib_1.__metadata("design:type", DatagridComponent)
    ], OrderitemComponent.prototype, "dataGrid_orderitemDataGrid", void 0);
    tslib_1.__decorate([
        HostBinding('class'),
        tslib_1.__metadata("design:type", Object)
    ], OrderitemComponent.prototype, "cls", void 0);
    OrderitemComponent = tslib_1.__decorate([
        Component({
            selector: 'app-orderitemcomponent',
            templateUrl: './orderitemcomponent.html',
            styleUrls: ['./orderitemcomponent.scss'],
            providers: [
                FARRIS_DEVKIT_FRAME_PROVIDERS,
                FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS,
                { provide: FRAME_ID, useValue: 'orderitem-component' },
                { provide: BindingData, useClass: BindingData },
                { provide: Repository, useExisting: SORepository },
                LangService,
                { provide: NAMESPACE, useValue: '' },
                { provide: ServerSideToken, useClass: BefLookupRestService },
                { provide: ComboServerSideToken, useClass: DefaultComboHttpService },
                { provide: GRID_SETTINGS_HTTP, useClass: BefLookupRestService },
                { provide: Form, useClass: OrderitemComponentViewmodelForm },
                { provide: UIState, useClass: OrderitemComponentViewmodelUIState },
                { provide: ViewModel, useClass: OrderitemComponentViewmodel },
                { provide: EXCEPTION_HANDLER, useValue: null },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: orderitemAddItem1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: orderitemRemoveItem1Handler, multi: true },
            ]
        }),
        tslib_1.__metadata("design:paramtypes", [WizardService,
            KeybindingService,
            LangService,
            ActivatedRoute,
            Router,
            ElementRef,
            LocalizationService,
            FrmI18nSettingService,
            FocusInvalidService,
            CommonUtils,
            DomSanitizer,
            Injector])
    ], OrderitemComponent);
    return OrderitemComponent;
}(FrameComponent));
export { OrderitemComponent };
