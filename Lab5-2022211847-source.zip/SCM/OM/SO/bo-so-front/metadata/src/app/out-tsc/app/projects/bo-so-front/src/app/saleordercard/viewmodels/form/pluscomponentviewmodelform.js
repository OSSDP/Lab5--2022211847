import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var PlusComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(PlusComponentViewmodelForm, _super);
    function PlusComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'fileInfo.fileInfo_Attachment',
            name: "{{fileInfo_FileInfo_Attachment_beda48ec_0lx6}}",
            binding: 'fileInfo.fileInfo_Attachment',
            updateOn: 'blur',
            defaultI18nValue: '附件Id',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], PlusComponentViewmodelForm.prototype, "fileInfo_FileInfo_Attachment", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'fileInfo.fileInfo_FileName',
            name: "{{fileInfo_FileInfo_FileName_fb0c4b5e_h66o}}",
            binding: 'fileInfo.fileInfo_FileName',
            updateOn: 'blur',
            defaultI18nValue: '附件名称',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], PlusComponentViewmodelForm.prototype, "fileInfo_FileInfo_FileName", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'fileInfo.fileInfo_FileSize',
            name: "{{fileInfo_FileInfo_FileSize_bed6f51d_v9nr}}",
            binding: 'fileInfo.fileInfo_FileSize',
            updateOn: 'blur',
            defaultI18nValue: '附件大小',
            validRules: [
                {
                    type: 'maxValue',
                    constraints: [1.7976931348623157e+308],
                },
                {
                    type: 'minValue',
                    constraints: [-1.7976931348623157e+308],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], PlusComponentViewmodelForm.prototype, "fileInfo_FileInfo_FileSize", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'fileInfo.fileInfo_FileCreate',
            name: "{{fileInfo_FileInfo_FileCreate_3e128aef_kbsh}}",
            binding: 'fileInfo.fileInfo_FileCreate',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '附件上传时间',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], PlusComponentViewmodelForm.prototype, "fileInfo_FileInfo_FileCreate", void 0);
    PlusComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '附件',
            enableValidate: true
        }),
        Injectable()
    ], PlusComponentViewmodelForm);
    return PlusComponentViewmodelForm;
}(Form));
export { PlusComponentViewmodelForm };
