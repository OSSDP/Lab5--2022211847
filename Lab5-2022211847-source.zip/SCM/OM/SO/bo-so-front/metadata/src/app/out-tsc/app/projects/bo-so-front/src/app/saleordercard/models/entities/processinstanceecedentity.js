import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var ProcessInstanceEcEdEntity = /** @class */ (function (_super) {
    tslib_1.__extends(ProcessInstanceEcEdEntity, _super);
    function ProcessInstanceEcEdEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ProcessInstance',
            dataField: 'processInstance',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ProcessInstance.ProcessInstance',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ProcessInstanceEcEdEntity.prototype, "processInstance", void 0);
    ProcessInstanceEcEdEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "ProcessInstance",
            nodeCode: "processInstance"
        })
    ], ProcessInstanceEcEdEntity);
    return ProcessInstanceEcEdEntity;
}(Entity));
export { ProcessInstanceEcEdEntity };
