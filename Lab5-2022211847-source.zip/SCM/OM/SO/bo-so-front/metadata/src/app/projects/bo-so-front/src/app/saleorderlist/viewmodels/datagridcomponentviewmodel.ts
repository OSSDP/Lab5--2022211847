
import { Injectable } from '@angular/core';
import { ViewModel, NgCommand } from '@farris/devkit';
import { Observable } from 'rxjs';

@Injectable()
export class DataGridComponentViewmodel extends ViewModel {
    public bindingPath = '/';
    // farrisDataGrid列集合定义 在对应component中赋值
    public dataGridColumns:any;
    // datGrid 列集合名称 用以bindData使用
    public dataGridColumnsName:string;

    public dom = {
  "dataGrid": {
    "type": "DataGrid",
    "resourceId": "dataGrid",
    "visible": {
      "useQuote": false,
      "isExpression": false,
      "value": true
    },
    "id": "dataGrid",
    "size": {},
    "readonly": {
      "useQuote": false,
      "isExpression": false,
      "value": false
    },
    "fields": [
      {
        "type": "GridField",
        "resourceId": "billStatus_BillState_50e3aa53_3sea",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "billStatus_BillState_50e3aa53_3sea",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "billStatus_BillState",
          "fullPath": "BillStatus.BillState",
          "isExpression": false,
          "value": "billStatus_BillState"
        },
        "dataField": "billStatus.billState",
        "dataType": "enum",
        "multiLanguage": false,
        "caption": "状态",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "enumData": [
          {
            "disabled": false,
            "name": "制单",
            "value": "Billing"
          },
          {
            "disabled": false,
            "name": "提交审批",
            "value": "SubmitApproval"
          },
          {
            "disabled": false,
            "name": "审批通过",
            "value": "Approved"
          },
          {
            "disabled": false,
            "name": "审批不通过",
            "value": "ApprovalNotPassed"
          }
        ],
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "orderCode_86945490_15in",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "orderCode_86945490_15in",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "orderCode",
          "fullPath": "OrderCode",
          "isExpression": false,
          "value": "orderCode"
        },
        "dataField": "orderCode",
        "dataType": "string",
        "multiLanguage": false,
        "caption": "订单编号",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": true,
        "updateOn": "blur",
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "merchant_Merchant_name_ca2fb712_oe0t",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "merchant_Merchant_name_ca2fb712_oe0t",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "merchant_Merchant_name",
          "fullPath": "Merchant.Merchant_name",
          "isExpression": false,
          "value": "merchant_Merchant_name"
        },
        "dataField": "merchant.merchant_name",
        "dataType": "string",
        "multiLanguage": false,
        "caption": "商户",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "orderPerson_OrderPerson_name_46cb53b8_bfb4",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "orderPerson_OrderPerson_name_46cb53b8_bfb4",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "orderPerson_OrderPerson_name",
          "fullPath": "OrderPerson.OrderPerson_name",
          "isExpression": false,
          "value": "orderPerson_OrderPerson_name"
        },
        "dataField": "orderPerson.orderPerson_name",
        "dataType": "string",
        "multiLanguage": false,
        "caption": "下单人",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "orderTime_d9062349_lu54",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "orderTime_d9062349_lu54",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "orderTime",
          "fullPath": "OrderTime",
          "isExpression": false,
          "value": "orderTime"
        },
        "dataField": "orderTime",
        "dataType": "string",
        "multiLanguage": false,
        "caption": "下单时间",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "updateOn": "blur",
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "payMethod_0fc73a46_ogsf",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "payMethod_0fc73a46_ogsf",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "payMethod",
          "fullPath": "PayMethod",
          "isExpression": false,
          "value": "payMethod"
        },
        "dataField": "payMethod",
        "dataType": "enum",
        "multiLanguage": false,
        "caption": "支付方式",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "resizeable": true,
        "enumData": [
          {
            "disabled": false,
            "name": "现金",
            "value": "Cash"
          },
          {
            "disabled": false,
            "name": "银联",
            "value": "Upay"
          },
          {
            "disabled": false,
            "name": "微信",
            "value": "WeChat"
          },
          {
            "disabled": false,
            "name": "支付宝",
            "value": "AliPay"
          }
        ],
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "updateOn": "change",
        "formatter": {
          "type": "none"
        }
      },
      {
        "type": "GridField",
        "resourceId": "orderState_cd5e1d95_x4qs",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "orderState_cd5e1d95_x4qs",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "orderState",
          "fullPath": "OrderState",
          "isExpression": false,
          "value": "orderState"
        },
        "dataField": "orderState",
        "dataType": "enum",
        "multiLanguage": false,
        "caption": "订单状态",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "enumData": [
          {
            "disabled": false,
            "name": "未发货",
            "value": "Unshipped"
          },
          {
            "disabled": false,
            "name": "已发货",
            "value": "Shipped"
          }
        ],
        "aggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "updateOn": "change",
        "formatter": {
          "type": "enum"
        }
      },
      {
        "type": "GridField",
        "resourceId": "totalPrice_c123bb96_yin6",
        "visible": {
          "useQuote": false,
          "isExpression": false,
          "value": true
        },
        "id": "totalPrice_c123bb96_yin6",
        "size": {
          "width": 120
        },
        "readonly": {
          "useQuote": false,
          "isExpression": false,
          "value": false
        },
        "binding": {
          "type": "Form",
          "path": "totalPrice",
          "fullPath": "TotalPrice",
          "isExpression": false,
          "value": "totalPrice"
        },
        "dataField": "totalPrice",
        "dataType": "number",
        "multiLanguage": false,
        "caption": "订单金额",
        "draggable": false,
        "frozen": "none",
        "sortable": true,
        "aggregate": {
          "type": "sum",
          "formatter": {
            "precision": 2,
            "thousand": ",",
            "prefix": "",
            "suffix": "元",
            "decimal": ".",
            "type": "number"
          }
        },
        "groupAggregate": {
          "type": "none",
          "formatter": {
            "type": "none"
          }
        },
        "linkedLabelEnabled": false,
        "updateOn": "blur",
        "formatter": {
          "type": "number",
          "precision": 2,
          "thousand": ",",
          "decimal": "."
        }
      }
    ],
    "multiSelect": false,
    "showLineNumber": false,
    "lineNumberTitle": "#",
    "groupTotalText": "Total",
    "filterable": false,
    "groupable": false,
    "rowClass": ""
  }
};
    @NgCommand({
        name: 'ChangePage1',
        params: {
            loadCommandName: 'Filter1',
            loadCommandFrameId: '#{root-component}'
        },
        paramDescriptions: {
            loadCommandName: { type: 'string' },
            loadCommandFrameId: { type: 'string' }
        }
    })
    public ChangePage1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'datagridView1',
        params: {
            url: 'fa51df80-8578-4eba-af52-4ab07c3e9d6d',
            params: '{"action":"LoadAndView1", "id":"{DATA~/#{data-grid-component}/id}"}',
            idToView: '',
            enableRefresh: 'false',
            tabName: '',
            destructuring: ''
        },
        paramDescriptions: {
            url: { type: 'string' },
            params: { type: 'string' },
            idToView: { type: 'string' },
            enableRefresh: { type: 'string' },
            tabName: { type: 'string' },
            destructuring: { type: 'string' }
        }
    })
    public datagridView1(commandParam?: any): Observable<any> { return; }

}