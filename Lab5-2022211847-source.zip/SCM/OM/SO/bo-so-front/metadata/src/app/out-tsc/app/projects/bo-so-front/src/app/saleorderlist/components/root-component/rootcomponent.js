import * as tslib_1 from "tslib";
import { Component, Injector, HostBinding, ElementRef } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Form, FrameComponent, FARRIS_DEVKIT_FRAME_PROVIDERS, ViewModel, COMMAND_HANDLERS_TOKEN, FRAME_ID, StateMachine, BindingData, Repository, UIState, Declaration, EXCEPTION_HANDLER, NAMESPACE } from '@farris/devkit';
import { FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS, ComponentManagerService } from '@farris/command-services';
import { KeybindingService } from '@farris/command-services';
import { ActivatedRoute, Router } from '@angular/router';
import { FrmI18nSettingService } from '@gsp-sys/rtf-common';
import { DomSanitizer } from '@angular/platform-browser';
import { WEBAPI_PREFIX_TOKEN } from '@farris/ui-common';
import { ExceptionHandler } from '@farris/command-services';
import { FrameworkSessionService, UriService } from '@farris/bef';
import { FrameworkService } from '@gsp-sys/rtf-common';
import { ApplicationParamService } from '@farris/command-services';
import { EventDeclaration } from '../../events/event';
import { FARRIS_DEVKIT_EXPRESSION_LISTENER_PROVIDERS, FARRIS_DEVKIT_EXPRESSION_EFFECTOR_PROVIDERS } from '@farris/devkit';
import { GSPFrameworkCommonService, resolveBasePath } from '@farris/rtf';
import { ENABLE_SERVER_SIDE_CHANGE_DETECTION_TOKEN } from '@farris/devkit';
import { WFSubmiteService } from '@gsp-wf/rtdevkit';
import { CloudprintService } from '@gsp-svc/cloudprint';
import { WFFlowchartService } from '@gsp-wf/ui-flowchart';
import { CHANGE_SET_POLICY_TOKEN } from '@farris/devkit';
import { TranslateToken, FARRIS_DEVKIT_EXPRESSION_ROOT_FRAME_PROVIDERS } from '@farris/devkit';
import { VerifyDetailService } from '@farris/ui-verify-detail';
import { AppContext, FORM_ID, PARAM_TYPE_TRANSFORM_TOKEN } from '@farris/devkit';
import { BE_SESSION_HANDLING_STRATEGY_TOKEN } from '@farris/bef';
import { BACK_END_MESSAGE_HANDLER_TOKEN } from '@farris/devkit';
import { BackEndMessageHandler } from '@farris/command-services';
import { BefLookupRestService, DefaultComboHttpService } from '@farris/bef';
import { ServerSideToken } from '@farris/ui-lookup';
import { ComboServerSideToken } from '@farris/ui-combo-list';
import { WizardService } from '@farris/ui-wizard';
import { LocalizationService } from "@farris/command-services";
import { RootViewmodel } from '../../viewmodels/rootviewmodel';
import { SORepository } from '../../models/sorepository';
import { LangService } from '../../lang/lang-pipe';
import { RootViewmodelForm } from '../../viewmodels/form/rootviewmodelform';
import { RootViewmodelStateMachine } from '../../viewmodels/statemachine/rootviewmodelstatemachine';
import { RootViewmodelUIState } from '../../viewmodels/uistate/rootviewmodeluistate';
import { Load1Handler } from '../../viewmodels/handlers/load1handler';
import { Search1Handler } from '../../viewmodels/handlers/search1handler';
import { RemoveRows1Handler } from '../../viewmodels/handlers/removerows1handler';
import { Add1Handler } from '../../viewmodels/handlers/add1handler';
import { View1Handler } from '../../viewmodels/handlers/view1handler';
import { Edit1Handler } from '../../viewmodels/handlers/edit1handler';
import { Remove1Handler } from '../../viewmodels/handlers/remove1handler';
import { Filter1Handler } from '../../viewmodels/handlers/filter1handler';
import { submitWithBizDefKey1Handler } from '../../viewmodels/handlers/submitwithbizdefkey1handler';
import { cancelSubmitWithDataId1Handler } from '../../viewmodels/handlers/cancelsubmitwithdataid1handler';
import { SOProxy } from '../../models/soproxy';
var ɵ0 = resolveBasePath;
var RootComponent = /** @class */ (function (_super) {
    tslib_1.__extends(RootComponent, _super);
    function RootComponent(wizardSer, keybindingService, langService, route, router, rootElement, localizationService, frmI18nSettingService, frameworkService, applicationParamsService, verifyService, stateMachine, sanitizer, injector) {
        var _this = _super.call(this, injector) || this;
        _this.wizardSer = wizardSer;
        _this.keybindingService = keybindingService;
        _this.langService = langService;
        _this.route = route;
        _this.router = router;
        _this.rootElement = rootElement;
        _this.localizationService = localizationService;
        _this.frmI18nSettingService = frmI18nSettingService;
        _this.frameworkService = frameworkService;
        _this.applicationParamsService = applicationParamsService;
        _this.verifyService = verifyService;
        _this.stateMachine = stateMachine;
        _this.sanitizer = sanitizer;
        _this.injector = injector;
        _this.cls = 'f-page-root  ';
        _this.lang = "";
        _this.size = {};
        _this.enabledLanguageList = [];
        _this.pageHeaderToolbarToolbarItems = [{
                "id": "button-add",
                "text": _this.langService.transform("button-add", _this.lang, "新增"),
                "resourceId": "button-add",
                "isDP": false,
                "class": "btn-primary",
                "tipsEnable": false,
                "icon": "",
                "children": []
            }, {
                "id": "button-edit",
                "text": _this.langService.transform("button-edit", _this.lang, "编辑"),
                "resourceId": "button-edit",
                "isDP": false,
                "tipsEnable": false,
                "icon": "",
                "children": []
            }, {
                "id": "button-view",
                "text": _this.langService.transform("button-view", _this.lang, "查看"),
                "resourceId": "button-view",
                "isDP": false,
                "tipsEnable": false,
                "icon": "",
                "children": []
            }, {
                "id": "button-delete",
                "text": _this.langService.transform("button-delete", _this.lang, "删除"),
                "resourceId": "button-delete",
                "isDP": false,
                "tipsEnable": false,
                "icon": "",
                "children": []
            }, {
                "id": "button-approve",
                "text": _this.langService.transform("button-approve", _this.lang, "提交审批"),
                "resourceId": "button-approve",
                "isDP": false,
                "tipsEnable": false,
                "icon": "",
                "children": []
            }, {
                "id": "button-cancel-approve",
                "text": _this.langService.transform("button-cancel-approve", _this.lang, "取消提交审批"),
                "resourceId": "button-cancel-approve",
                "isDP": false,
                "tipsEnable": false,
                "icon": "",
                "children": []
            }
        ];
        _this.pageHeaderToolbarToolbarItemsStates = new BehaviorSubject({});
        _this.pageHeaderToolbarToolbarItemsVisibleStates = new BehaviorSubject({});
        _this.tabsToolbarStates = new BehaviorSubject({});
        _this.tabsToolbarVisibleStates = new BehaviorSubject({});
        _this.sectionsToolbarStates = new BehaviorSubject({});
        _this.sectionsToolbarVisibleStates = new BehaviorSubject({});
        _this.querySchemeSection = {
            position: 'inHead',
            contents: []
        };
        _this.SectionqueryschemesectionMainTitle = _this.langService.transform("Section/query-scheme-section/mainTitle", _this.lang, "主标题");
        _this.SectionqueryschemesectionSubTitle = _this.langService.transform("Section/query-scheme-section/subTitle", _this.lang, "");
        _this.filterTextqueryscheme1 = _this.langService.transform("QueryScheme/query-scheme-1/filterText", _this.lang, "筛选");
        _this.QuerySolutionqueryscheme1 = _this.langService.transform("query-scheme-1", _this.lang, "默认筛选方案");
        _this.fieldConfigsqueryscheme1 = [
            {
                "id": "bc6ca04c-1a9c-4ed9-bbd4-996abba917a7",
                "labelCode": "ID",
                "code": "ID",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/bc6ca04c-1a9c-4ed9-bbd4-996abba917a7", _this.lang, "主键"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/bc6ca04c-1a9c-4ed9-bbd4-996abba917a7/placeHolder", _this.lang, ""),
                "control": { "id": "bc6ca04c-1a9c-4ed9-bbd4-996abba917a7", "controltype": "text", "require": false, "className": "", "modalConfig": { "modalCmp": null, "mapFields": null, "showHeader": true, "title": "", "showCloseButton": true, "showMaxButton": true, "width": 800, "height": 600, "showFooterButtons": true, "footerButtons": [] } }
            },
            {
                "id": "d4c87cf1-22be-4e18-a0d4-ff249ef5a453",
                "labelCode": "Version",
                "code": "Version",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/d4c87cf1-22be-4e18-a0d4-ff249ef5a453", _this.lang, "版本"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/d4c87cf1-22be-4e18-a0d4-ff249ef5a453/placeHolder", _this.lang, ""),
                "control": { "id": "d4c87cf1-22be-4e18-a0d4-ff249ef5a453", "controltype": "date", "require": false, "format": "yyyy-MM-dd", "weekSelect": false, "startFieldCode": "Version", "endFieldCode": "Version" }
            },
            {
                "id": "50e3aa53-0101-468f-ae3f-40c76c0f06b0",
                "labelCode": "BillStatus.BillState",
                "code": "BillState",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0", _this.lang, "状态"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/placeHolder", _this.lang, ""),
                "control": {
                    "controltype": "dropdown",
                    "require": false,
                    "valueType": "1",
                    "multiSelect": false,
                    "enumValues": [
                        {
                            "value": "Billing",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/control/enumValues/Billing", _this.lang, "制单")
                        },
                        {
                            "value": "SubmitApproval",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/control/enumValues/SubmitApproval", _this.lang, "提交审批")
                        },
                        {
                            "value": "Approved",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/control/enumValues/Approved", _this.lang, "审批通过")
                        },
                        {
                            "value": "ApprovalNotPassed",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/control/enumValues/ApprovalNotPassed", _this.lang, "审批不通过")
                        }
                    ]
                }
            },
            {
                "id": "8f847609-ad8f-4da3-a430-c8a7f2162135",
                "labelCode": "ProcessInstance.ProcessInstance",
                "code": "ProcessInstance",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/8f847609-ad8f-4da3-a430-c8a7f2162135", _this.lang, "流程实例"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/8f847609-ad8f-4da3-a430-c8a7f2162135/placeHolder", _this.lang, ""),
                "control": { "id": "8f847609-ad8f-4da3-a430-c8a7f2162135", "controltype": "text", "require": false, "className": "" }
            },
            {
                "id": "86945490-de67-44d5-922e-2af156aa1843",
                "labelCode": "OrderCode",
                "code": "OrderCode",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/86945490-de67-44d5-922e-2af156aa1843", _this.lang, "订单编号"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/86945490-de67-44d5-922e-2af156aa1843/placeHolder", _this.lang, ""),
                "control": { "id": "86945490-de67-44d5-922e-2af156aa1843", "controltype": "text", "require": false, "className": "" }
            },
            {
                "id": "17e72c5d-2086-4ccb-8d3f-045b109e64a8",
                "labelCode": "Merchant.Merchant",
                "code": "Merchant",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/17e72c5d-2086-4ccb-8d3f-045b109e64a8", _this.lang, "商户"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/17e72c5d-2086-4ccb-8d3f-045b109e64a8/placeHolder", _this.lang, ""),
                "control": { "id": "17e72c5d-2086-4ccb-8d3f-045b109e64a8", "controltype": "text", "require": false, "className": "" }
            },
            {
                "id": "ca2fb712-9f37-4cd3-803a-fa2fcb1b2abc",
                "labelCode": "Merchant.Merchant_name",
                "code": "name",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/ca2fb712-9f37-4cd3-803a-fa2fcb1b2abc", _this.lang, "商户"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/ca2fb712-9f37-4cd3-803a-fa2fcb1b2abc/placeHolder", _this.lang, ""),
                "control": {
                    "controltype": "help",
                    "require": false,
                    "uri": "SO.merchant_Merchant_name",
                    "textField": "name",
                    "valueField": "name",
                    "idField": "id",
                    "helpId": "b524a702-7323-4d46-998e-5ba0c6abcd49",
                    "displayType": "TreeList",
                    "loadTreeDataType": 'default',
                    "enableFullTree": false,
                    "editable": false,
                    "dialogTitle": _this.langService.transform("QueryScheme/query-scheme-1/ca2fb712-9f37-4cd3-803a-fa2fcb1b2abc/control/help/dialogTitle", _this.lang, ""),
                    "singleSelect": true,
                    "enableCascade": false,
                    "cascadeStatus": "enable",
                    "pageSize": 20,
                    "pageList": "10,20,30,50",
                    "nosearch": false,
                    "expandLevel": -1,
                    "enableMultiFieldSearch": false,
                    "context": {
                        "enableExtendLoadMethod": true
                    },
                    "quickSelect": {
                        "enable": false,
                        "showMore": true,
                        "showItemsCount": 10
                    }
                }
            },
            {
                "id": "d9062349-66f1-4b4d-94ae-3a3450fde511",
                "labelCode": "OrderTime",
                "code": "OrderTime",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/d9062349-66f1-4b4d-94ae-3a3450fde511", _this.lang, "下单时间"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/d9062349-66f1-4b4d-94ae-3a3450fde511/placeHolder", _this.lang, ""),
                "control": { "id": "d9062349-66f1-4b4d-94ae-3a3450fde511", "controltype": "date", "require": false, "format": "yyyy-MM-dd", "returnFormat": "yyyy-MM-dd", "weekSelect": false, "className": "" }
            },
            {
                "id": "0fc73a46-3f15-4438-b023-8564e094ae3f",
                "labelCode": "PayMethod",
                "code": "PayMethod",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/0fc73a46-3f15-4438-b023-8564e094ae3f", _this.lang, "支付方式"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/0fc73a46-3f15-4438-b023-8564e094ae3f/placeHolder", _this.lang, ""),
                "control": {
                    "controltype": "dropdown",
                    "require": false,
                    "valueType": "1",
                    "multiSelect": false,
                    "enumValues": [
                        {
                            "value": "Cash",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/0fc73a46-3f15-4438-b023-8564e094ae3f/control/enumValues/Cash", _this.lang, "现金")
                        },
                        {
                            "value": "Upay",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/0fc73a46-3f15-4438-b023-8564e094ae3f/control/enumValues/Upay", _this.lang, "银联")
                        },
                        {
                            "value": "WeChat",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/0fc73a46-3f15-4438-b023-8564e094ae3f/control/enumValues/WeChat", _this.lang, "微信")
                        },
                        {
                            "value": "AliPay",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/0fc73a46-3f15-4438-b023-8564e094ae3f/control/enumValues/AliPay", _this.lang, "支付宝")
                        }
                    ]
                }
            },
            {
                "id": "a313bbbc-7e47-4ea0-ae9d-0d4c443e17f6",
                "labelCode": "OrderType",
                "code": "OrderType",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/a313bbbc-7e47-4ea0-ae9d-0d4c443e17f6", _this.lang, "订单类型"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/a313bbbc-7e47-4ea0-ae9d-0d4c443e17f6/placeHolder", _this.lang, ""),
                "control": { "id": "a313bbbc-7e47-4ea0-ae9d-0d4c443e17f6", "controltype": "text", "require": false, "className": "" }
            },
            {
                "id": "5ffb5340-afa6-4871-a96d-4685e3a1f0c8",
                "labelCode": "OrderPerson.OrderPerson",
                "code": "OrderPerson",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/5ffb5340-afa6-4871-a96d-4685e3a1f0c8", _this.lang, "下单人"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/5ffb5340-afa6-4871-a96d-4685e3a1f0c8/placeHolder", _this.lang, ""),
                "control": { "id": "5ffb5340-afa6-4871-a96d-4685e3a1f0c8", "controltype": "text", "require": false, "className": "" }
            },
            {
                "id": "46cb53b8-60e6-4264-8de1-e8a5731c673f",
                "labelCode": "OrderPerson.OrderPerson_name",
                "code": "name",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/46cb53b8-60e6-4264-8de1-e8a5731c673f", _this.lang, "名称"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/46cb53b8-60e6-4264-8de1-e8a5731c673f/placeHolder", _this.lang, ""),
                "control": { "id": "46cb53b8-60e6-4264-8de1-e8a5731c673f", "controltype": "text", "require": false, "className": "", "modalConfig": { "modalCmp": null, "mapFields": null, "showHeader": true, "title": "", "showCloseButton": true, "showMaxButton": true, "width": 800, "height": 600, "showFooterButtons": true, "footerButtons": [] } }
            },
            {
                "id": "fe4d6422-eefc-4a5a-b6a1-dc0618d82f68",
                "labelCode": "Telephone",
                "code": "Telephone",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/fe4d6422-eefc-4a5a-b6a1-dc0618d82f68", _this.lang, "联系电话"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/fe4d6422-eefc-4a5a-b6a1-dc0618d82f68/placeHolder", _this.lang, ""),
                "control": { "id": "fe4d6422-eefc-4a5a-b6a1-dc0618d82f68", "controltype": "text", "require": false, "className": "" }
            },
            {
                "id": "cd5e1d95-8e87-41fd-b951-a4a0bbf039d3",
                "labelCode": "OrderState",
                "code": "OrderState",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/cd5e1d95-8e87-41fd-b951-a4a0bbf039d3", _this.lang, "订单状态"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/cd5e1d95-8e87-41fd-b951-a4a0bbf039d3/placeHolder", _this.lang, ""),
                "control": {
                    "controltype": "dropdown",
                    "require": false,
                    "valueType": "1",
                    "multiSelect": false,
                    "enumValues": [
                        {
                            "value": "Unshipped",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/cd5e1d95-8e87-41fd-b951-a4a0bbf039d3/control/enumValues/Unshipped", _this.lang, "未发货")
                        },
                        {
                            "value": "Shipped",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/cd5e1d95-8e87-41fd-b951-a4a0bbf039d3/control/enumValues/Shipped", _this.lang, "已发货")
                        }
                    ]
                }
            },
            {
                "id": "729382b8-1f97-4133-971a-443c00dcfa80",
                "labelCode": "Remark",
                "code": "Remark",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/729382b8-1f97-4133-971a-443c00dcfa80", _this.lang, "备注"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/729382b8-1f97-4133-971a-443c00dcfa80/placeHolder", _this.lang, ""),
                "control": { "id": "729382b8-1f97-4133-971a-443c00dcfa80", "controltype": "text", "require": false, "className": "" }
            },
            {
                "id": "c123bb96-1c33-4d29-bb6a-faf065df8e3a",
                "labelCode": "TotalPrice",
                "code": "TotalPrice",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/c123bb96-1c33-4d29-bb6a-faf065df8e3a", _this.lang, "订单金额"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/c123bb96-1c33-4d29-bb6a-faf065df8e3a/placeHolder", _this.lang, ""),
                "control": { "id": "c123bb96-1c33-4d29-bb6a-faf065df8e3a", "controltype": "number", "require": false, "className": "", "textAlign": "left", "precision": 2, "isBigNumber": false }
            }
        ];
        _this.presetFieldConfigsqueryscheme1 = [
            {
                "id": "50e3aa53-0101-468f-ae3f-40c76c0f06b0",
                "labelCode": "BillStatus.BillState",
                "code": "BillState",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0", _this.lang, "状态"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/placeHolder", _this.lang, ""),
                "control": {
                    "controltype": "dropdown",
                    "require": false,
                    "valueType": "1",
                    "multiSelect": false,
                    "enumValues": [
                        {
                            "value": "Billing",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/control/enumValues/Billing", _this.lang, "制单")
                        },
                        {
                            "value": "SubmitApproval",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/control/enumValues/SubmitApproval", _this.lang, "提交审批")
                        },
                        {
                            "value": "Approved",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/control/enumValues/Approved", _this.lang, "审批通过")
                        },
                        {
                            "value": "ApprovalNotPassed",
                            "name": _this.langService.transform("QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/control/enumValues/ApprovalNotPassed", _this.lang, "审批不通过")
                        }
                    ]
                }
            },
            {
                "id": "86945490-de67-44d5-922e-2af156aa1843",
                "labelCode": "OrderCode",
                "code": "OrderCode",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/86945490-de67-44d5-922e-2af156aa1843", _this.lang, "订单编号"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/86945490-de67-44d5-922e-2af156aa1843/placeHolder", _this.lang, ""),
                "control": { "id": "86945490-de67-44d5-922e-2af156aa1843", "controltype": "text", "require": false, "className": "" }
            },
            {
                "id": "ca2fb712-9f37-4cd3-803a-fa2fcb1b2abc",
                "labelCode": "Merchant.Merchant_name",
                "code": "name",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/ca2fb712-9f37-4cd3-803a-fa2fcb1b2abc", _this.lang, "商户"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/ca2fb712-9f37-4cd3-803a-fa2fcb1b2abc/placeHolder", _this.lang, ""),
                "control": {
                    "controltype": "help",
                    "require": false,
                    "uri": "SO.merchant_Merchant_name",
                    "textField": "name",
                    "valueField": "name",
                    "idField": "id",
                    "helpId": "b524a702-7323-4d46-998e-5ba0c6abcd49",
                    "displayType": "TreeList",
                    "loadTreeDataType": 'default',
                    "enableFullTree": false,
                    "editable": false,
                    "dialogTitle": _this.langService.transform("QueryScheme/query-scheme-1/ca2fb712-9f37-4cd3-803a-fa2fcb1b2abc/control/help/dialogTitle", _this.lang, ""),
                    "singleSelect": true,
                    "enableCascade": false,
                    "cascadeStatus": "enable",
                    "pageSize": 20,
                    "pageList": "10,20,30,50",
                    "nosearch": false,
                    "expandLevel": -1,
                    "enableMultiFieldSearch": false,
                    "context": {
                        "enableExtendLoadMethod": true
                    },
                    "quickSelect": {
                        "enable": false,
                        "showMore": true,
                        "showItemsCount": 10
                    }
                }
            },
            {
                "id": "d9062349-66f1-4b4d-94ae-3a3450fde511",
                "labelCode": "OrderTime",
                "code": "OrderTime",
                "name": _this.langService.transform("QueryScheme/query-scheme-1/d9062349-66f1-4b4d-94ae-3a3450fde511", _this.lang, "下单时间"),
                "placeHolder": _this.langService.transform("QueryScheme/query-scheme-1/d9062349-66f1-4b4d-94ae-3a3450fde511/placeHolder", _this.lang, ""),
                "control": { "id": "d9062349-66f1-4b4d-94ae-3a3450fde511", "controltype": "date", "require": false, "format": "yyyy-MM-dd", "returnFormat": "yyyy-MM-dd", "weekSelect": false, "className": "" }
            }
        ];
        _this.lang = localStorage.getItem('languageCode') || "zh-CHS";
        if (_this.frmI18nSettingService) {
            var i18nSetting = _this.frmI18nSettingService.getSetting();
            if (i18nSetting && i18nSetting.languages && i18nSetting.languages.length > 0) {
                i18nSetting.languages.forEach(function (item) {
                    _this.enabledLanguageList.push({
                        code: item.code,
                        name: item.name
                    });
                });
            }
            else {
                console.warn("get current enable languages is null. if this occurs,please ensure the form into the framework.");
                _this.enabledLanguageList.push({ "code": "en", "name": "English" });
                _this.enabledLanguageList.push({ "code": "zh-CHS", "name": "中文简体" });
            }
        }
        return _this;
    }
    RootComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.keybindingService) {
            this.viewModel.keybindingMap.forEach(function (keyBinding, method) {
                _this.keybindingService.register(keyBinding, function () {
                    return _this.viewModel[method]();
                });
            });
        }
        this.viewModel.verifycationChanged.subscribe(function (verifyInformations) {
            if (verifyInformations.length) {
                _this.verifyService.createVerify({
                    'parent': _this.rootElement,
                    'verifyList': verifyInformations,
                    'showType': 'all',
                    'showList': true
                });
            }
            else {
                _this.verifyService.clear();
            }
        });
        this.stateMachine.stateChange.subscribe(function () {
            var pageHeaderToolbarToolbarItemsstates = {
                'button-add': !_this.viewModel.stateMachine['canAdd'],
                'button-edit': !_this.viewModel.stateMachine['canEdit'],
                'button-view': !_this.viewModel.stateMachine['canView'],
                'button-delete': !_this.viewModel.stateMachine['canRemove'],
                'button-approve': !_this.viewModel.stateMachine['canApprove'],
                'button-cancel-approve': !_this.viewModel.stateMachine['canCancelApprove'],
            };
            _this.pageHeaderToolbarToolbarItemsStates.next(pageHeaderToolbarToolbarItemsstates);
        });
        this.stateMachine.stateChange.subscribe(function () {
            var pageHeaderToolbarToolbarItemsvisibleStates = {
                'button-add': true,
                'button-edit': true,
                'button-view': true,
                'button-delete': true,
                'button-approve': true,
                'button-cancel-approve': true,
            };
            _this.pageHeaderToolbarToolbarItemsVisibleStates.next(pageHeaderToolbarToolbarItemsvisibleStates);
        });
        this.pageHeaderToolbarToolbarItems.forEach(function (toolbarItem) {
            var transformText = _this.langService.transform(toolbarItem.resourceId, _this.lang, toolbarItem.text);
            if (transformText) {
                toolbarItem.text = transformText;
            }
        });
        this.applicationParamsService.parseParams(this.route, this.frameworkService, this.viewModel, function () {
            _this.onFormLoad();
        });
    };
    RootComponent.prototype.ngAfterViewInit = function () {
    };
    RootComponent.prototype.ngOnDestroy = function () {
        // 增加表单的自我销毁
        this.context.dispose && this.context.dispose();
        this.context = null;
        this.subscription = null;
        this.declaration = null;
        this.wizardSer = null;
        this.keybindingService = null;
        this.langService = null;
        this.route = null;
        this.router = null;
        this.rootElement = null;
        this.localizationService = null;
        this.frmI18nSettingService = null;
        this.frameworkService = null;
        this.applicationParamsService = null;
        this.verifyService.clear();
        this.verifyService = null;
        this.stateMachine = null;
        this.sanitizer = null;
        this.injector = null;
        this.enabledLanguageList = [];
    };
    RootComponent.prototype.handleSizeChange = function (size) {
        this.size = size;
    };
    RootComponent.prototype.onFormLoad = function () {
        this.viewModel.Filter1();
    };
    RootComponent.prototype.pageHeaderToolbarClickHandler = function (args) {
        switch (args.id) {
            case 'button-add':
                this.viewModel.Add1(args);
                break;
            case 'button-edit':
                this.viewModel.Edit1(args);
                break;
            case 'button-view':
                this.viewModel.View1(args);
                break;
            case 'button-delete':
                this.viewModel.Remove1(args);
                break;
            case 'button-approve':
                this.viewModel.submitWithBizDefKey1(args);
                break;
            case 'button-cancel-approve':
                this.viewModel.cancelSubmitWithDataId1(args);
                break;
        }
    };
    tslib_1.__decorate([
        HostBinding('class'),
        tslib_1.__metadata("design:type", Object)
    ], RootComponent.prototype, "cls", void 0);
    RootComponent = tslib_1.__decorate([
        Component({
            selector: 'app-rootcomponent',
            templateUrl: './rootcomponent.html',
            styleUrls: ['./rootcomponent.scss'],
            providers: [
                FARRIS_DEVKIT_FRAME_PROVIDERS,
                FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS,
                { provide: FRAME_ID, useValue: 'root-component' },
                { provide: BindingData, useClass: BindingData },
                { provide: Repository, useExisting: SORepository },
                LangService,
                { provide: NAMESPACE, useValue: '' },
                { provide: ServerSideToken, useClass: BefLookupRestService },
                { provide: ComboServerSideToken, useClass: DefaultComboHttpService },
                { provide: Form, useClass: RootViewmodelForm },
                { provide: StateMachine, useClass: RootViewmodelStateMachine },
                { provide: UIState, useClass: RootViewmodelUIState },
                FrameworkSessionService,
                UriService,
                SOProxy,
                SORepository,
                { provide: ViewModel, useClass: RootViewmodel },
                { provide: Declaration, useClass: EventDeclaration },
                { provide: TranslateToken, useExisting: LangService },
                { provide: ENABLE_SERVER_SIDE_CHANGE_DETECTION_TOKEN, useValue: false },
                { provide: WEBAPI_PREFIX_TOKEN, useFactory: ɵ0, deps: [GSPFrameworkCommonService] },
                VerifyDetailService,
                { provide: WFSubmiteService, useClass: WFSubmiteService },
                { provide: CloudprintService, useClass: CloudprintService },
                { provide: WFFlowchartService, useClass: WFFlowchartService },
                FARRIS_DEVKIT_EXPRESSION_LISTENER_PROVIDERS,
                FARRIS_DEVKIT_EXPRESSION_EFFECTOR_PROVIDERS,
                FARRIS_DEVKIT_EXPRESSION_ROOT_FRAME_PROVIDERS,
                AppContext,
                ComponentManagerService,
                { provide: PARAM_TYPE_TRANSFORM_TOKEN, useValue: false },
                { provide: FORM_ID, useValue: "c18959b7-ec42-4018-a93e-bc950da420d5" },
                { provide: BE_SESSION_HANDLING_STRATEGY_TOKEN, useValue: "SeparatedSession" },
                { provide: EXCEPTION_HANDLER, useClass: ExceptionHandler },
                { provide: CHANGE_SET_POLICY_TOKEN, useValue: 'valid' },
                { provide: BACK_END_MESSAGE_HANDLER_TOKEN, useClass: BackEndMessageHandler },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: Load1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: Search1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: RemoveRows1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: Add1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: View1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: Edit1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: Remove1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: Filter1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: submitWithBizDefKey1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: cancelSubmitWithDataId1Handler, multi: true },
            ]
        }),
        tslib_1.__metadata("design:paramtypes", [WizardService,
            KeybindingService,
            LangService,
            ActivatedRoute,
            Router,
            ElementRef,
            LocalizationService,
            FrmI18nSettingService,
            FrameworkService,
            ApplicationParamService,
            VerifyDetailService,
            StateMachine,
            DomSanitizer,
            Injector])
    ], RootComponent);
    return RootComponent;
}(FrameComponent));
export { RootComponent };
export { ɵ0 };
