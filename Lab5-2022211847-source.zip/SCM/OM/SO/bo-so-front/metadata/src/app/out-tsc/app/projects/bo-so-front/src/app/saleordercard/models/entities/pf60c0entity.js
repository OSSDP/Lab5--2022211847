import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var PF60c0Entity = /** @class */ (function (_super) {
    tslib_1.__extends(PF60c0Entity, _super);
    function PF60c0Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'FileInfo',
            dataField: 'fileInfo',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'FileInfo.FileInfo',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], PF60c0Entity.prototype, "fileInfo", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Attachment',
            dataField: 'fileInfo_Attachment',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'FileInfo.FileInfo_Attachment',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], PF60c0Entity.prototype, "fileInfo_Attachment", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'FileName',
            dataField: 'fileInfo_FileName',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'FileInfo.FileInfo_FileName',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], PF60c0Entity.prototype, "fileInfo_FileName", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'FileSize',
            dataField: 'fileInfo_FileSize',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'FileInfo.FileInfo_FileSize',
        }),
        tslib_1.__metadata("design:type", Object)
    ], PF60c0Entity.prototype, "fileInfo_FileSize", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'FileCreate',
            dataField: 'fileInfo_FileCreate',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'FileInfo.FileInfo_FileCreate',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], PF60c0Entity.prototype, "fileInfo_FileCreate", void 0);
    PF60c0Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "FileInfo",
            nodeCode: "fileInfo"
        })
    ], PF60c0Entity);
    return PF60c0Entity;
}(Entity));
export { PF60c0Entity };
