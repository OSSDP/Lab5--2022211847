import * as tslib_1 from "tslib";
import { Component, Injector, ViewChild, HostBinding, ElementRef } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Form, FrameComponent, FARRIS_DEVKIT_FRAME_PROVIDERS, ViewModel, FRAME_ID, BindingData, Repository, UIState, EXCEPTION_HANDLER, NAMESPACE } from '@farris/devkit';
import { FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS, ComponentManagerService } from '@farris/command-services';
import { KeybindingService } from '@farris/command-services';
import { ActivatedRoute, Router } from '@angular/router';
import { FrmI18nSettingService } from '@gsp-sys/rtf-common';
import { DomSanitizer } from '@angular/platform-browser';
import { FocusInvalidService } from '@farris/command-services';
import { LookupGridComponent } from '@farris/ui-lookup';
import { BefLookupRestService, DefaultComboHttpService } from '@farris/bef';
import { ServerSideToken } from '@farris/ui-lookup';
import { ComboServerSideToken } from '@farris/ui-combo-list';
import { WizardService } from '@farris/ui-wizard';
import { LocalizationService } from "@farris/command-services";
import { BasicFormViewmodel } from '../../viewmodels/basicformviewmodel';
import { SORepository } from '../../models/sorepository';
import { LangService } from '../../lang/lang-pipe';
import { BasicFormViewmodelForm } from '../../viewmodels/form/basicformviewmodelform';
import { BasicFormViewmodelUIState } from '../../viewmodels/uistate/basicformviewmodeluistate';
var BasicFormComponent = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormComponent, _super);
    function BasicFormComponent(wizardSer, keybindingService, langService, route, router, rootElement, localizationService, frmI18nSettingService, focusInvalidService, componentManagerService, sanitizer, injector) {
        var _this = _super.call(this, injector) || this;
        _this.wizardSer = wizardSer;
        _this.keybindingService = keybindingService;
        _this.langService = langService;
        _this.route = route;
        _this.router = router;
        _this.rootElement = rootElement;
        _this.localizationService = localizationService;
        _this.frmI18nSettingService = frmI18nSettingService;
        _this.focusInvalidService = focusInvalidService;
        _this.componentManagerService = componentManagerService;
        _this.sanitizer = sanitizer;
        _this.injector = injector;
        _this.cls = 'f-struct-wrapper ';
        _this.lang = "";
        _this.size = {};
        _this.enabledLanguageList = [];
        _this.tabsToolbarStates = new BehaviorSubject({});
        _this.tabsToolbarVisibleStates = new BehaviorSubject({});
        _this.FieldSetTitle59966a8835a342298482f42d595000a7 = _this.langService.transform("59966a88-35a3-4229-8482-f42d595000a7", _this.lang, "基本信息");
        _this.FieldSetCollapseText59966a8835a342298482f42d595000a7 = _this.langService.transform("FieldSet/59966a88-35a3-4229-8482-f42d595000a7/collapseText", _this.lang, "");
        _this.FieldSetExpandText59966a8835a342298482f42d595000a7 = _this.langService.transform("FieldSet/59966a88-35a3-4229-8482-f42d595000a7/expandText", _this.lang, "");
        _this.FieldSetTitle999b88aa05f24baa8acab44df208eb5c = _this.langService.transform("999b88aa-05f2-4baa-8aca-b44df208eb5c", _this.lang, "支付信息");
        _this.FieldSetCollapseText999b88aa05f24baa8acab44df208eb5c = _this.langService.transform("FieldSet/999b88aa-05f2-4baa-8aca-b44df208eb5c/collapseText", _this.lang, "");
        _this.FieldSetExpandText999b88aa05f24baa8acab44df208eb5c = _this.langService.transform("FieldSet/999b88aa-05f2-4baa-8aca-b44df208eb5c/expandText", _this.lang, "");
        _this.SectionbasicformsectionMainTitle = _this.langService.transform("Section/basic-form-section/mainTitle", _this.lang, "基本信息");
        _this.SectionbasicformsectionSubTitle = _this.langService.transform("Section/basic-form-section/subTitle", _this.lang, "");
        _this.LookupEditmerchantMerchantnamedc52b9570e1vDialogTitle = _this.langService.transform("LookupEdit/merchant_Merchant_name_dc52b957_0e1v/dialogTitle", _this.lang, "");
        _this.merchant_Merchant_name_dc52b957_0e1v_PlaceHolder = _this.langService.transform("LookupEdit/merchant_Merchant_name_dc52b957_0e1v/placeHolder", _this.lang, "");
        _this.merchant_Merchant_name_dc52b957_0e1vQuickSelect = {
            "enable": false,
            "showItemsCount": 10,
            "showMore": true
        };
        _this.LookupEditorderPersonOrderPersonname2d1d302a0aakDialogTitle = _this.langService.transform("LookupEdit/orderPerson_OrderPerson_name_2d1d302a_0aak/dialogTitle", _this.lang, "");
        _this.orderPerson_OrderPerson_name_2d1d302a_0aak_PlaceHolder = _this.langService.transform("LookupEdit/orderPerson_OrderPerson_name_2d1d302a_0aak/placeHolder", _this.lang, "");
        _this.orderPerson_OrderPerson_name_2d1d302a_0aakQuickSelect = {
            "enable": false,
            "showItemsCount": 10,
            "showMore": true
        };
        _this.totalPrice_a6bb5a5f_5ugx_PlaceHolder = _this.langService.transform("NumericBox/totalPrice_a6bb5a5f_5ugx/placeHolder", _this.lang, "");
        _this.totalPriceA6bb5a5f5ugxTextOptions = {
            "type": "number",
            "useThousands": true,
            "precision": 2,
        };
        _this.billStatus_BillState_df94470c_t04qEnumData = [
            {
                "name": _this.langService.transform("EnumField/billStatus_BillState_df94470c_t04q/enumData/Billing", _this.lang, "制单"),
                "value": "Billing",
                "disabled": false
            },
            {
                "name": _this.langService.transform("EnumField/billStatus_BillState_df94470c_t04q/enumData/SubmitApproval", _this.lang, "提交审批"),
                "value": "SubmitApproval",
                "disabled": false
            },
            {
                "name": _this.langService.transform("EnumField/billStatus_BillState_df94470c_t04q/enumData/Approved", _this.lang, "审批通过"),
                "value": "Approved",
                "disabled": false
            },
            {
                "name": _this.langService.transform("EnumField/billStatus_BillState_df94470c_t04q/enumData/ApprovalNotPassed", _this.lang, "审批不通过"),
                "value": "ApprovalNotPassed",
                "disabled": false
            }
        ];
        _this.billStatus_BillState_df94470c_t04q_PlaceHolder = _this.langService.transform("EnumField/billStatus_BillState_df94470c_t04q/placeHolder", _this.lang, "");
        _this.orderState_8665667d_dfjnEnumData = [
            {
                "name": _this.langService.transform("EnumField/orderState_8665667d_dfjn/enumData/Unshipped", _this.lang, "未发货"),
                "value": "Unshipped",
                "disabled": false
            },
            {
                "name": _this.langService.transform("EnumField/orderState_8665667d_dfjn/enumData/Shipped", _this.lang, "已发货"),
                "value": "Shipped",
                "disabled": false
            }
        ];
        _this.orderState_8665667d_dfjn_PlaceHolder = _this.langService.transform("EnumField/orderState_8665667d_dfjn/placeHolder", _this.lang, "");
        _this.payMethod_5e15710a_1paoEnumData = [
            {
                "name": _this.langService.transform("EnumField/payMethod_5e15710a_1pao/enumData/Cash", _this.lang, "现金"),
                "value": "Cash",
                "disabled": false
            },
            {
                "name": _this.langService.transform("EnumField/payMethod_5e15710a_1pao/enumData/Upay", _this.lang, "银联"),
                "value": "Upay",
                "disabled": false
            },
            {
                "name": _this.langService.transform("EnumField/payMethod_5e15710a_1pao/enumData/WeChat", _this.lang, "微信"),
                "value": "WeChat",
                "disabled": false
            },
            {
                "name": _this.langService.transform("EnumField/payMethod_5e15710a_1pao/enumData/AliPay", _this.lang, "支付宝"),
                "value": "AliPay",
                "disabled": false
            }
        ];
        _this.payMethod_5e15710a_1pao_PlaceHolder = _this.langService.transform("EnumField/payMethod_5e15710a_1pao/placeHolder", _this.lang, "");
        _this.orderCode_f2d9e158_kgvz_PlaceHolder = _this.langService.transform("TextBox/orderCode_f2d9e158_kgvz/placeHolder", _this.lang, "");
        _this.orderTime_898df2fe_xjlg_PlaceHolder = _this.langService.transform("TextBox/orderTime_898df2fe_xjlg/placeHolder", _this.lang, "");
        _this.telephone_a1f41ba4_yxps_PlaceHolder = _this.langService.transform("TextBox/telephone_a1f41ba4_yxps/placeHolder", _this.lang, "");
        _this.remark_e5d2dfa9_cljr_PlaceHolder = _this.langService.transform("TextBox/remark_e5d2dfa9_cljr/placeHolder", _this.lang, "");
        _this.orderType_86c9e32c_ivwq_PlaceHolder = _this.langService.transform("TextBox/orderType_86c9e32c_ivwq/placeHolder", _this.lang, "");
        _this.lang = localStorage.getItem('languageCode') || "zh-CHS";
        _this.viewModel.verifycationChanged.subscribe(function (verifyInformations) {
            _this.focusInvalidService.focusInvalidInput(verifyInformations, _this.rootElement);
        });
        if (_this.frmI18nSettingService) {
            var i18nSetting = _this.frmI18nSettingService.getSetting();
            if (i18nSetting && i18nSetting.languages && i18nSetting.languages.length > 0) {
                i18nSetting.languages.forEach(function (item) {
                    _this.enabledLanguageList.push({
                        code: item.code,
                        name: item.name
                    });
                });
            }
            else {
                console.warn("get current enable languages is null. if this occurs,please ensure the form into the framework.");
                _this.enabledLanguageList.push({ "code": "en", "name": "English" });
                _this.enabledLanguageList.push({ "code": "zh-CHS", "name": "中文简体" });
            }
        }
        return _this;
    }
    BasicFormComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.keybindingService) {
            this.viewModel.keybindingMap.forEach(function (keyBinding, method) {
                _this.keybindingService.register(keyBinding, function () {
                    return _this.viewModel[method]();
                });
            });
        }
        this.onFormLoad();
    };
    BasicFormComponent.prototype.ngAfterViewInit = function () {
        this.componentManagerService.appendControl('merchant_Merchant_name_dc52b957_0e1v', this.merchant_Merchant_name_dc52b957_0e1v);
        this.componentManagerService.appendControl('orderPerson_OrderPerson_name_2d1d302a_0aak', this.orderPerson_OrderPerson_name_2d1d302a_0aak);
    };
    BasicFormComponent.prototype.ngOnDestroy = function () {
        // 增加表单的自我销毁
        this.context.dispose && this.context.dispose();
        this.context = null;
        this.subscription = null;
        this.declaration = null;
        this.wizardSer = null;
        this.keybindingService = null;
        this.langService = null;
        this.route = null;
        this.router = null;
        this.rootElement = null;
        this.localizationService = null;
        this.frmI18nSettingService = null;
        this.focusInvalidService = null;
        this.sanitizer = null;
        this.injector = null;
        this.enabledLanguageList = [];
    };
    BasicFormComponent.prototype.handleSizeChange = function (size) {
        this.size = size;
    };
    BasicFormComponent.prototype.onFormLoad = function () {
    };
    tslib_1.__decorate([
        ViewChild('merchant_Merchant_name_dc52b957_0e1v'),
        tslib_1.__metadata("design:type", LookupGridComponent)
    ], BasicFormComponent.prototype, "merchant_Merchant_name_dc52b957_0e1v", void 0);
    tslib_1.__decorate([
        ViewChild('orderPerson_OrderPerson_name_2d1d302a_0aak'),
        tslib_1.__metadata("design:type", LookupGridComponent)
    ], BasicFormComponent.prototype, "orderPerson_OrderPerson_name_2d1d302a_0aak", void 0);
    tslib_1.__decorate([
        HostBinding('class'),
        tslib_1.__metadata("design:type", Object)
    ], BasicFormComponent.prototype, "cls", void 0);
    BasicFormComponent = tslib_1.__decorate([
        Component({
            selector: 'app-basicformcomponent',
            templateUrl: './basicformcomponent.html',
            styleUrls: ['./basicformcomponent.scss'],
            providers: [
                FARRIS_DEVKIT_FRAME_PROVIDERS,
                FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS,
                { provide: FRAME_ID, useValue: 'basic-form-component' },
                { provide: BindingData, useClass: BindingData },
                { provide: Repository, useExisting: SORepository },
                LangService,
                { provide: NAMESPACE, useValue: '' },
                { provide: ServerSideToken, useClass: BefLookupRestService },
                { provide: ComboServerSideToken, useClass: DefaultComboHttpService },
                { provide: Form, useClass: BasicFormViewmodelForm },
                { provide: UIState, useClass: BasicFormViewmodelUIState },
                { provide: ViewModel, useClass: BasicFormViewmodel },
                { provide: EXCEPTION_HANDLER, useValue: null },
            ]
        }),
        tslib_1.__metadata("design:paramtypes", [WizardService,
            KeybindingService,
            LangService,
            ActivatedRoute,
            Router,
            ElementRef,
            LocalizationService,
            FrmI18nSettingService,
            FocusInvalidService,
            ComponentManagerService,
            DomSanitizer,
            Injector])
    ], BasicFormComponent);
    return BasicFormComponent;
}(FrameComponent));
export { BasicFormComponent };
