import * as tslib_1 from "tslib";
import { Entity, NgField, NgObject, NgEntity } from '@farris/devkit';
import { PF60c0Entity } from './pf60c0entity';
var PlusEntity = /** @class */ (function (_super) {
    tslib_1.__extends(PlusEntity, _super);
    function PlusEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], PlusEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ParentID',
            dataField: 'parentID',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ParentID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], PlusEntity.prototype, "parentID", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'fileInfo',
            originalDataField: 'FileInfo',
            type: PF60c0Entity
        }),
        tslib_1.__metadata("design:type", PF60c0Entity)
    ], PlusEntity.prototype, "fileInfo", void 0);
    PlusEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "Plus",
            nodeCode: "pluss"
        })
    ], PlusEntity);
    return PlusEntity;
}(Entity));
export { PlusEntity };
