import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ViewModel, NgCommand } from '@farris/devkit';
import { Observable } from 'rxjs';
var ɵ0 = { type: 'string' };
var OrderitemComponentViewmodel = /** @class */ (function (_super) {
    tslib_1.__extends(OrderitemComponentViewmodel, _super);
    function OrderitemComponentViewmodel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bindingPath = '/orderItems';
        _this.dom = {
            "dataGrid_orderitem": {
                "type": "DataGrid",
                "resourceId": "dataGrid_orderitem",
                "visible": {
                    "useQuote": false,
                    "isExpression": false,
                    "value": true
                },
                "id": "dataGrid_orderitem",
                "size": {},
                "readonly": {
                    "useQuote": false,
                    "isExpression": false,
                    "value": false
                },
                "fields": [
                    {
                        "type": "GridField",
                        "resourceId": "goods_Goods_GoodsName_cd37eccb_m6h9",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "goods_Goods_GoodsName_cd37eccb_m6h9",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "goods_Goods_GoodsName",
                            "fullPath": "Goods.Goods_GoodsName",
                            "isExpression": false,
                            "value": "goods_Goods_GoodsName"
                        },
                        "dataField": "goods.goods_GoodsName",
                        "dataType": "string",
                        "multiLanguage": false,
                        "caption": "商品名称",
                        "editor": {
                            "type": "LookupEdit",
                            "isTextArea": true,
                            "resourceId": "goods_Goods_GoodsName_cd37eccb_bgad",
                            "defaultI18nValue": "商品名称",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "goods_Goods_GoodsName_cd37eccb_bgad",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "goods_Goods_GoodsName",
                                "fullPath": "Goods.Goods_GoodsName",
                                "isExpression": false,
                                "value": "goods_Goods_GoodsName"
                            },
                            "disable": false,
                            "dataSource": {
                                "uri": "OrderItem.goods_Goods_GoodsName",
                                "displayName": "商品帮助",
                                "idField": "id",
                                "type": "ViewObject",
                                "helpCode": "GoodsLookUp"
                            },
                            "valueField": "goodsName",
                            "textField": "goodsName",
                            "multiSelect": false,
                            "pageSize": 20,
                            "mapFields": {
                                "id": "goods.goods",
                                "goodsName": "goods.goods_GoodsName",
                                "specification": "goods.goods_Specification",
                                "price": "price"
                            },
                            "displayType": "List",
                            "enableExtendLoadMethod": true,
                            "editable": false,
                            "noSearch": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "useTip": false,
                            "useFavorite": true,
                            "enableToSelect": true,
                            "isRecordSize": false,
                            "expandLevel": -1,
                            "enableFullTree": false,
                            "context": {
                                "enableExtendLoadMethod": true
                            },
                            "loadTreeDataType": "default",
                            "enableClear": true,
                            "enableCascade": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "goods_Goods_Specification_a9d828f8_of7o",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "goods_Goods_Specification_a9d828f8_of7o",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "binding": {
                            "type": "Form",
                            "path": "goods_Goods_Specification",
                            "fullPath": "Goods.Goods_Specification",
                            "isExpression": false,
                            "value": "goods_Goods_Specification"
                        },
                        "dataField": "goods.goods_Specification",
                        "dataType": "string",
                        "multiLanguage": false,
                        "caption": "规格型号",
                        "editor": {
                            "type": "TextBox",
                            "isTextArea": true,
                            "resourceId": "goods_Goods_Specification_a9d828f8_jn7y",
                            "defaultI18nValue": "规格型号",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "goods_Goods_Specification_a9d828f8_jn7y",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "goods_Goods_Specification",
                                "isExpression": false,
                                "value": "goods_Goods_Specification"
                            },
                            "disable": false,
                            "maxLength": 36,
                            "isPassword": false,
                            "enableViewPassword": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "quality_aad2548f_ijrt",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "quality_aad2548f_ijrt",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "quality",
                            "fullPath": "Quality",
                            "isExpression": false,
                            "value": "quality"
                        },
                        "dataField": "quality",
                        "dataType": "number",
                        "multiLanguage": false,
                        "caption": "数量",
                        "editor": {
                            "type": "FarrisNumberSpinner",
                            "isTextArea": true,
                            "resourceId": "quality_aad2548f_g2gf",
                            "defaultI18nValue": "数量",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "quality_aad2548f_g2gf",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "quality",
                                "isExpression": false,
                                "value": "quality"
                            },
                            "disable": false,
                            "step": 1,
                            "useThousands": true,
                            "textAlign": "left",
                            "precision": 0
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "blur",
                        "formatter": {
                            "type": "number",
                            "precision": 0,
                            "thousand": ",",
                            "decimal": "."
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "price_1a57e03c_wmqb",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "price_1a57e03c_wmqb",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "price",
                            "fullPath": "Price",
                            "isExpression": false,
                            "value": "price"
                        },
                        "dataField": "price",
                        "dataType": "number",
                        "multiLanguage": false,
                        "caption": "标准单价",
                        "editor": {
                            "type": "FarrisNumberSpinner",
                            "isTextArea": true,
                            "resourceId": "price_1a57e03c_47bs",
                            "defaultI18nValue": "标准单价",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "price_1a57e03c_47bs",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "price",
                                "isExpression": false,
                                "value": "price"
                            },
                            "disable": false,
                            "step": 1,
                            "useThousands": true,
                            "textAlign": "left",
                            "precision": 2
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "blur",
                        "formatter": {
                            "type": "number",
                            "precision": 2,
                            "thousand": ",",
                            "decimal": "."
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "actualPrice_ffcf39b2_qt08",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "actualPrice_ffcf39b2_qt08",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "actualPrice",
                            "fullPath": "ActualPrice",
                            "isExpression": false,
                            "value": "actualPrice"
                        },
                        "dataField": "actualPrice",
                        "dataType": "number",
                        "multiLanguage": false,
                        "caption": "实际单价",
                        "editor": {
                            "type": "FarrisNumberSpinner",
                            "isTextArea": true,
                            "resourceId": "actualPrice_ffcf39b2_oiwl",
                            "defaultI18nValue": "实际单价",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "actualPrice_ffcf39b2_oiwl",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "actualPrice",
                                "isExpression": false,
                                "value": "actualPrice"
                            },
                            "disable": false,
                            "step": 1,
                            "useThousands": true,
                            "textAlign": "left",
                            "precision": 2
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "blur",
                        "formatter": {
                            "type": "number",
                            "precision": 2,
                            "thousand": ",",
                            "decimal": "."
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "discountType_c9be5f52_qw4r",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "discountType_c9be5f52_qw4r",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "discountType",
                            "fullPath": "DiscountType",
                            "isExpression": false,
                            "value": "discountType"
                        },
                        "dataField": "discountType",
                        "dataType": "enum",
                        "multiLanguage": false,
                        "caption": "折扣类型",
                        "editor": {
                            "type": "ComboList",
                            "isTextArea": true,
                            "resourceId": "discountType_c9be5f52_25o9",
                            "defaultI18nValue": "折扣类型",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "discountType_c9be5f52_25o9",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "discountType",
                                "isExpression": false,
                                "value": "discountType"
                            },
                            "disable": false,
                            "editable": false,
                            "idField": "value",
                            "textField": "name",
                            "multiSelect": false,
                            "data": [
                                {
                                    "disabled": false,
                                    "name": "折扣",
                                    "value": "Dis"
                                },
                                {
                                    "disabled": false,
                                    "name": "无折扣",
                                    "value": "NoDIs"
                                }
                            ],
                            "autoWidth": true
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "enumData": [
                            {
                                "disabled": false,
                                "name": "折扣",
                                "value": "Dis"
                            },
                            {
                                "disabled": false,
                                "name": "无折扣",
                                "value": "NoDIs"
                            }
                        ],
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "change",
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "discount_92ee9f2f_or2b",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "discount_92ee9f2f_or2b",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "discount",
                            "fullPath": "Discount",
                            "isExpression": false,
                            "value": "discount"
                        },
                        "dataField": "discount",
                        "dataType": "string",
                        "multiLanguage": false,
                        "caption": "折扣",
                        "editor": {
                            "type": "TextBox",
                            "isTextArea": true,
                            "resourceId": "discount_92ee9f2f_dkwy",
                            "defaultI18nValue": "折扣",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "discount_92ee9f2f_dkwy",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "discount",
                                "isExpression": false,
                                "value": "discount"
                            },
                            "disable": false,
                            "maxLength": 10,
                            "isPassword": false,
                            "enableViewPassword": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "blur",
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "amount_9b7b1a84_vfjl",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "amount_9b7b1a84_vfjl",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "amount",
                            "fullPath": "Amount",
                            "isExpression": false,
                            "value": "amount"
                        },
                        "dataField": "amount",
                        "dataType": "number",
                        "multiLanguage": false,
                        "caption": "结算金额",
                        "editor": {
                            "type": "FarrisNumberSpinner",
                            "isTextArea": true,
                            "resourceId": "amount_9b7b1a84_luhv",
                            "defaultI18nValue": "结算金额",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "amount_9b7b1a84_luhv",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "amount",
                                "isExpression": false,
                                "value": "amount"
                            },
                            "disable": false,
                            "step": 1,
                            "useThousands": true,
                            "textAlign": "left",
                            "precision": 2
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "blur",
                        "formatter": {
                            "type": "number",
                            "precision": 2,
                            "thousand": ",",
                            "decimal": "."
                        }
                    }
                ],
                "multiSelect": false,
                "editable": "viewModel.stateMachine['editable']",
                "showLineNumber": false,
                "lineNumberTitle": "#",
                "groupTotalText": "Total",
                "filterable": false,
                "groupable": false,
                "rowClass": ""
            }
        };
        return _this;
    }
    OrderitemComponentViewmodel.prototype.orderitemAddItem1 = function (commandParam) { return; };
    OrderitemComponentViewmodel.prototype.orderitemRemoveItem1 = function (commandParam) { return; };
    tslib_1.__decorate([
        NgCommand({
            name: 'orderitemAddItem1',
            params: {}
        }),
        tslib_1.__metadata("design:type", Function),
        tslib_1.__metadata("design:paramtypes", [Object]),
        tslib_1.__metadata("design:returntype", Observable)
    ], OrderitemComponentViewmodel.prototype, "orderitemAddItem1", null);
    tslib_1.__decorate([
        NgCommand({
            name: 'orderitemRemoveItem1',
            params: {
                id: '{DATA~/#{orderitem-component}/orderItems/id}'
            },
            paramDescriptions: {
                id: ɵ0
            }
        }),
        tslib_1.__metadata("design:type", Function),
        tslib_1.__metadata("design:paramtypes", [Object]),
        tslib_1.__metadata("design:returntype", Observable)
    ], OrderitemComponentViewmodel.prototype, "orderitemRemoveItem1", null);
    OrderitemComponentViewmodel = tslib_1.__decorate([
        Injectable()
    ], OrderitemComponentViewmodel);
    return OrderitemComponentViewmodel;
}(ViewModel));
export { OrderitemComponentViewmodel };
export { ɵ0 };
