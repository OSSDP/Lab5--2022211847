import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var OrderitemComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(OrderitemComponentViewmodelForm, _super);
    function OrderitemComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'goods.goods_GoodsName',
            name: "{{goods_Goods_GoodsName_cd37eccb_m6h9}}",
            binding: 'goods.goods_GoodsName',
            updateOn: 'blur',
            defaultI18nValue: '商品名称',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], OrderitemComponentViewmodelForm.prototype, "goods_Goods_GoodsName", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'goods.goods_Specification',
            name: "{{goods_Goods_Specification_a9d828f8_of7o}}",
            binding: 'goods.goods_Specification',
            updateOn: 'blur',
            defaultI18nValue: '规格型号',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], OrderitemComponentViewmodelForm.prototype, "goods_Goods_Specification", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'quality',
            name: "{{quality_aad2548f_ijrt}}",
            binding: 'quality',
            updateOn: 'blur',
            defaultI18nValue: '数量',
            validRules: [
                {
                    type: 'maxValue',
                    constraints: [1.7976931348623157e+308],
                },
                {
                    type: 'minValue',
                    constraints: [-1.7976931348623157e+308],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], OrderitemComponentViewmodelForm.prototype, "quality", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'price',
            name: "{{price_1a57e03c_wmqb}}",
            binding: 'price',
            updateOn: 'blur',
            defaultI18nValue: '标准单价',
            validRules: [
                {
                    type: 'maxValue',
                    constraints: [1.7976931348623157e+308],
                },
                {
                    type: 'minValue',
                    constraints: [-1.7976931348623157e+308],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], OrderitemComponentViewmodelForm.prototype, "price", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'actualPrice',
            name: "{{actualPrice_ffcf39b2_qt08}}",
            binding: 'actualPrice',
            updateOn: 'blur',
            defaultI18nValue: '实际单价',
            validRules: [
                {
                    type: 'maxValue',
                    constraints: [1.7976931348623157e+308],
                },
                {
                    type: 'minValue',
                    constraints: [-1.7976931348623157e+308],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], OrderitemComponentViewmodelForm.prototype, "actualPrice", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'discountType',
            name: "{{discountType_c9be5f52_qw4r}}",
            binding: 'discountType',
            updateOn: 'change',
            defaultI18nValue: '折扣类型',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], OrderitemComponentViewmodelForm.prototype, "discountType", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'discount',
            name: "{{discount_92ee9f2f_or2b}}",
            binding: 'discount',
            updateOn: 'blur',
            defaultI18nValue: '折扣',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], OrderitemComponentViewmodelForm.prototype, "discount", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'amount',
            name: "{{amount_9b7b1a84_vfjl}}",
            binding: 'amount',
            updateOn: 'blur',
            defaultI18nValue: '结算金额',
            validRules: [
                {
                    type: 'maxValue',
                    constraints: [1.7976931348623157e+308],
                },
                {
                    type: 'minValue',
                    constraints: [-1.7976931348623157e+308],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], OrderitemComponentViewmodelForm.prototype, "amount", void 0);
    OrderitemComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '订单明细',
            enableValidate: true
        }),
        Injectable()
    ], OrderitemComponentViewmodelForm);
    return OrderitemComponentViewmodelForm;
}(Form));
export { OrderitemComponentViewmodelForm };
