
import { Pipe, PipeTransform, Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError, switchMap } from "rxjs/operators";
import { HttpClient } from '@angular/common/http';
import { DomSanitizer} from '@angular/platform-browser';
import { BasePathService } from '@farris/rtf';
export function createTranslateLoader(http: HttpClient,version:string) {
  let versionSuffix = "";
  if (version) {
    versionSuffix = "?v=" + version;
  }
  return new TranslateHttpLoader(http, BasePathService.convertPath('/apps/scm/om/web/bo-so-front/saleorderlist/i18n/'), '.json'+ versionSuffix);
}

export let lang = {"zh-CHS":{"root-component":"","root-layout":"","query-scheme-section":"","Section/query-scheme-section/mainTitle":"主标题","Section/query-scheme-section/subTitle":"","query-scheme-1":"默认筛选方案","QueryScheme/query-scheme-1/filterText":"筛选","QueryScheme/query-scheme-1/bc6ca04c-1a9c-4ed9-bbd4-996abba917a7":"主键","QueryScheme/query-scheme-1/bc6ca04c-1a9c-4ed9-bbd4-996abba917a7/placeHolder":"","QueryScheme/query-scheme-1/d4c87cf1-22be-4e18-a0d4-ff249ef5a453":"版本","QueryScheme/query-scheme-1/d4c87cf1-22be-4e18-a0d4-ff249ef5a453/placeHolder":"","QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0":"状态","QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/placeHolder":"","QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/control/enumValues/Billing":"制单","QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/control/enumValues/SubmitApproval":"提交审批","QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/control/enumValues/Approved":"审批通过","QueryScheme/query-scheme-1/50e3aa53-0101-468f-ae3f-40c76c0f06b0/control/enumValues/ApprovalNotPassed":"审批不通过","QueryScheme/query-scheme-1/8f847609-ad8f-4da3-a430-c8a7f2162135":"流程实例","QueryScheme/query-scheme-1/8f847609-ad8f-4da3-a430-c8a7f2162135/placeHolder":"","QueryScheme/query-scheme-1/86945490-de67-44d5-922e-2af156aa1843":"订单编号","QueryScheme/query-scheme-1/86945490-de67-44d5-922e-2af156aa1843/placeHolder":"","QueryScheme/query-scheme-1/17e72c5d-2086-4ccb-8d3f-045b109e64a8":"商户","QueryScheme/query-scheme-1/17e72c5d-2086-4ccb-8d3f-045b109e64a8/placeHolder":"","QueryScheme/query-scheme-1/ca2fb712-9f37-4cd3-803a-fa2fcb1b2abc":"商户","QueryScheme/query-scheme-1/ca2fb712-9f37-4cd3-803a-fa2fcb1b2abc/placeHolder":"","QueryScheme/query-scheme-1/ca2fb712-9f37-4cd3-803a-fa2fcb1b2abc/control/help/dialogTitle":"","QueryScheme/query-scheme-1/d9062349-66f1-4b4d-94ae-3a3450fde511":"下单时间","QueryScheme/query-scheme-1/d9062349-66f1-4b4d-94ae-3a3450fde511/placeHolder":"","QueryScheme/query-scheme-1/0fc73a46-3f15-4438-b023-8564e094ae3f":"支付方式","QueryScheme/query-scheme-1/0fc73a46-3f15-4438-b023-8564e094ae3f/placeHolder":"","QueryScheme/query-scheme-1/0fc73a46-3f15-4438-b023-8564e094ae3f/control/enumValues/Cash":"现金","QueryScheme/query-scheme-1/0fc73a46-3f15-4438-b023-8564e094ae3f/control/enumValues/Upay":"银联","QueryScheme/query-scheme-1/0fc73a46-3f15-4438-b023-8564e094ae3f/control/enumValues/WeChat":"微信","QueryScheme/query-scheme-1/0fc73a46-3f15-4438-b023-8564e094ae3f/control/enumValues/AliPay":"支付宝","QueryScheme/query-scheme-1/a313bbbc-7e47-4ea0-ae9d-0d4c443e17f6":"订单类型","QueryScheme/query-scheme-1/a313bbbc-7e47-4ea0-ae9d-0d4c443e17f6/placeHolder":"","QueryScheme/query-scheme-1/5ffb5340-afa6-4871-a96d-4685e3a1f0c8":"下单人","QueryScheme/query-scheme-1/5ffb5340-afa6-4871-a96d-4685e3a1f0c8/placeHolder":"","QueryScheme/query-scheme-1/46cb53b8-60e6-4264-8de1-e8a5731c673f":"名称","QueryScheme/query-scheme-1/46cb53b8-60e6-4264-8de1-e8a5731c673f/placeHolder":"","QueryScheme/query-scheme-1/fe4d6422-eefc-4a5a-b6a1-dc0618d82f68":"联系电话","QueryScheme/query-scheme-1/fe4d6422-eefc-4a5a-b6a1-dc0618d82f68/placeHolder":"","QueryScheme/query-scheme-1/cd5e1d95-8e87-41fd-b951-a4a0bbf039d3":"订单状态","QueryScheme/query-scheme-1/cd5e1d95-8e87-41fd-b951-a4a0bbf039d3/placeHolder":"","QueryScheme/query-scheme-1/cd5e1d95-8e87-41fd-b951-a4a0bbf039d3/control/enumValues/Unshipped":"未发货","QueryScheme/query-scheme-1/cd5e1d95-8e87-41fd-b951-a4a0bbf039d3/control/enumValues/Shipped":"已发货","QueryScheme/query-scheme-1/729382b8-1f97-4133-971a-443c00dcfa80":"备注","QueryScheme/query-scheme-1/729382b8-1f97-4133-971a-443c00dcfa80/placeHolder":"","QueryScheme/query-scheme-1/c123bb96-1c33-4d29-bb6a-faf065df8e3a":"订单金额","QueryScheme/query-scheme-1/c123bb96-1c33-4d29-bb6a-faf065df8e3a/placeHolder":"","page-header":"","header-nav":"","header-title-container":"","page-header-title":"","title":"销售订单列表","page-header-toolbar":"","button-add":"新增","button-edit":"编辑","button-view":"查看","button-delete":"删除","button-approve":"提交审批","button-cancel-approve":"取消提交审批","page-main":"","data-grid-component-ref":"","data-grid-component":"","data-grid-section":"","Section/data-grid-section/mainTitle":"","Section/data-grid-section/subTitle":"","dataGrid":"","DataGrid/dataGrid/lineNumberTitle":"","DataGrid/dataGrid/OperateEditButton":"编辑","DataGrid/dataGrid/OperateDeleteButton":"删除","DataGrid/dataGrid/OperateColumn":"操作","billStatus_BillState_50e3aa53_3sea":"状态","GridField/billStatus_BillState_50e3aa53_3sea/enumData/Billing":"制单","GridField/billStatus_BillState_50e3aa53_3sea/enumData/SubmitApproval":"提交审批","GridField/billStatus_BillState_50e3aa53_3sea/enumData/Approved":"审批通过","GridField/billStatus_BillState_50e3aa53_3sea/enumData/ApprovalNotPassed":"审批不通过","orderCode_86945490_15in":"订单编号","merchant_Merchant_name_ca2fb712_oe0t":"商户","orderPerson_OrderPerson_name_46cb53b8_bfb4":"下单人","orderTime_d9062349_lu54":"下单时间","payMethod_0fc73a46_ogsf":"支付方式","GridField/payMethod_0fc73a46_ogsf/enumData/Cash":"现金","GridField/payMethod_0fc73a46_ogsf/enumData/Upay":"银联","GridField/payMethod_0fc73a46_ogsf/enumData/WeChat":"微信","GridField/payMethod_0fc73a46_ogsf/enumData/AliPay":"支付宝","orderState_cd5e1d95_x4qs":"订单状态","GridField/orderState_cd5e1d95_x4qs/enumData/Unshipped":"未发货","GridField/orderState_cd5e1d95_x4qs/enumData/Shipped":"已发货","totalPrice_c123bb96_yin6":"订单金额"}};

@Pipe({ name: 'lang' })
export class LangPipe implements PipeTransform {
  constructor(private translate: TranslateService, private http: HttpClient) { }
  transform(key: string, langCode: string, defaultValue?: string) {
      
    const translateValue = this.translate.instant(key);
    if (translateValue == "JitI18nDefaultValue") {
      return defaultValue ? defaultValue : "";
    }

    return translateValue;
  }
}
@Pipe({ name: 'safeHtml' })
export class SafeHtmlPipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) { }
  transform(url) {
    if (!url) {
      url = "";
    }
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}
@Injectable()
export class LangService {
  constructor(private translate: TranslateService) { }
  transform(key: string, langCode: string, defaultValue?: string) {
    
    const translateValue = this.translate.instant(key);
    if (translateValue == "JitI18nDefaultValue") {
      return defaultValue ? defaultValue : "";
    }

    return translateValue;
  }

  getCurrentLanguage() {
    return this.translate.currentLang;
  }

}

@Injectable()
export class TranslateResolveService implements Resolve<any>{

  constructor(private translate: TranslateService, private http: HttpClient) {
    translate.defaultLang = 'zh-CHS';
    translate.setTranslation('zh-CHS', lang['zh-CHS']);
  }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> {
    let langCode = localStorage.getItem('languageCode');
    if (!langCode) {
      langCode = "zh-CHS";
    }
    if (langCode == "zh-CHS" || (this.translate.defaultLang === langCode && this.translate.currentLoader == createTranslateLoader(this.http,null))) {
      this.translate.setTranslation('zh-CHS', lang['zh-CHS']);
      return of(this.translate[langCode]);
    } else {
      const httpOb = this.http.get(BasePathService.getBasePath() + "/apps/scm/om/web/bo-so-front/version.json?v=" + new Date().getTime()).pipe(switchMap((data)=>{
        let currentVersion = null;
        if (data instanceof Array) {
          const versionKey = "saleorderlist/" + langCode + ".json";
          data.forEach((item) => {
            if (item.category == "i18n" && item.key == versionKey) {
              currentVersion = item.value;
            }
          });
        }

        this.translate.defaultLang = langCode;
        this.translate.currentLang = langCode;
        this.translate.currentLoader = createTranslateLoader(this.http, currentVersion);

    let tran = this.translate.getTranslation(langCode).pipe(catchError(err => {
      console.error("read resource file failed,please check!!! "+ err);
      return of(err);
    }));
    return tran;
      }));
      return httpOb;
    }
  }
}
