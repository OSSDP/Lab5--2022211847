
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '销售订单',
    enableValidate: true
})

@Injectable()
export class BasicFormViewmodelForm extends Form {
    @NgFormControl({
        id: 'billStatus_BillState_df94470c_t04q',
        name: "{{billStatus_BillState_df94470c_t04q}}",
        binding: 'billStatus.billState',
        updateOn: 'change',
        defaultI18nValue: '单据状态',
    })
    billStatus_BillState: FormControl;

    @NgFormControl({
        id: 'orderCode_f2d9e158_kgvz',
        name: "{{orderCode_f2d9e158_kgvz}}",
        binding: 'orderCode',
        updateOn: 'blur',
        defaultI18nValue: '订单编号',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    orderCode: FormControl;

    @NgFormControl({
        id: 'merchant_Merchant_name_dc52b957_0e1v',
        name: "{{merchant_Merchant_name_dc52b957_0e1v}}",
        binding: 'merchant.merchant_name',
        updateOn: 'blur',
        defaultI18nValue: '商户',
    })
    merchant_Merchant_name: FormControl;

    @NgFormControl({
        id: 'orderTime_898df2fe_xjlg',
        name: "{{orderTime_898df2fe_xjlg}}",
        binding: 'orderTime',
        updateOn: 'blur',
        defaultI18nValue: '下单时间',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    orderTime: FormControl;

    @NgFormControl({
        id: 'payMethod_5e15710a_1pao',
        name: "{{payMethod_5e15710a_1pao}}",
        binding: 'payMethod',
        updateOn: 'change',
        defaultI18nValue: '支付方式',
    })
    payMethod: FormControl;

    @NgFormControl({
        id: 'orderType_86c9e32c_ivwq',
        name: "{{orderType_86c9e32c_ivwq}}",
        binding: 'orderType',
        updateOn: 'blur',
        defaultI18nValue: '订单类型',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    orderType: FormControl;

    @NgFormControl({
        id: 'orderPerson_OrderPerson_name_2d1d302a_0aak',
        name: "{{orderPerson_OrderPerson_name_2d1d302a_0aak}}",
        binding: 'orderPerson.orderPerson_name',
        updateOn: 'blur',
        defaultI18nValue: '下单人',
    })
    orderPerson_OrderPerson_name: FormControl;

    @NgFormControl({
        id: 'telephone_a1f41ba4_yxps',
        name: "{{telephone_a1f41ba4_yxps}}",
        binding: 'telephone',
        updateOn: 'blur',
        defaultI18nValue: '联系电话',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    telephone: FormControl;

    @NgFormControl({
        id: 'orderState_8665667d_dfjn',
        name: "{{orderState_8665667d_dfjn}}",
        binding: 'orderState',
        updateOn: 'change',
        defaultI18nValue: '订单状态',
    })
    orderState: FormControl;

    @NgFormControl({
        id: 'remark_e5d2dfa9_cljr',
        name: "{{remark_e5d2dfa9_cljr}}",
        binding: 'remark',
        updateOn: 'blur',
        defaultI18nValue: '备注',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    remark: FormControl;

    @NgFormControl({
        id: 'totalPrice_a6bb5a5f_5ugx',
        name: "{{totalPrice_a6bb5a5f_5ugx}}",
        binding: 'totalPrice',
        updateOn: 'blur',
        defaultI18nValue: '订单金额',
    })
    totalPrice: FormControl;

}