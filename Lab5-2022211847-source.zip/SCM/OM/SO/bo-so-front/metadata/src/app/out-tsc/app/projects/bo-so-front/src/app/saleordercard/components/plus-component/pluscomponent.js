import * as tslib_1 from "tslib";
import { Component, Injector, ViewChild, HostBinding, ElementRef } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Form, FrameComponent, FARRIS_DEVKIT_FRAME_PROVIDERS, ViewModel, COMMAND_HANDLERS_TOKEN, FRAME_ID, BindingData, Repository, UIState, EXCEPTION_HANDLER, NAMESPACE } from '@farris/devkit';
import { FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS } from '@farris/command-services';
import { KeybindingService } from '@farris/command-services';
import { ActivatedRoute, Router } from '@angular/router';
import { FrmI18nSettingService } from '@gsp-sys/rtf-common';
import { DomSanitizer } from '@angular/platform-browser';
import { FocusInvalidService } from '@farris/command-services';
import { EditorTypes } from '@farris/ui-datagrid-editors';
import { DatagridComponent, GRID_SETTINGS_HTTP } from '@farris/ui-datagrid';
import { CommonUtils } from '@farris/ui-common';
import { BefLookupRestService, DefaultComboHttpService } from '@farris/bef';
import { ServerSideToken } from '@farris/ui-lookup';
import { ComboServerSideToken } from '@farris/ui-combo-list';
import { WizardService } from '@farris/ui-wizard';
import { LocalizationService } from "@farris/command-services";
import { PlusComponentViewmodel } from '../../viewmodels/pluscomponentviewmodel';
import { SORepository } from '../../models/sorepository';
import { LangService } from '../../lang/lang-pipe';
import { PlusComponentViewmodelForm } from '../../viewmodels/form/pluscomponentviewmodelform';
import { PlusComponentViewmodelUIState } from '../../viewmodels/uistate/pluscomponentviewmodeluistate';
import { plusAddItem1Handler } from '../../viewmodels/handlers/plusadditem1handler';
import { plusRemoveItem1Handler } from '../../viewmodels/handlers/plusremoveitem1handler';
var PlusComponent = /** @class */ (function (_super) {
    tslib_1.__extends(PlusComponent, _super);
    function PlusComponent(wizardSer, keybindingService, langService, route, router, rootElement, localizationService, frmI18nSettingService, focusInvalidService, farrisGridUtils, sanitizer, injector) {
        var _this = _super.call(this, injector) || this;
        _this.wizardSer = wizardSer;
        _this.keybindingService = keybindingService;
        _this.langService = langService;
        _this.route = route;
        _this.router = router;
        _this.rootElement = rootElement;
        _this.localizationService = localizationService;
        _this.frmI18nSettingService = frmI18nSettingService;
        _this.focusInvalidService = focusInvalidService;
        _this.farrisGridUtils = farrisGridUtils;
        _this.sanitizer = sanitizer;
        _this.injector = injector;
        _this.dataGrid_plusColumns = [];
        _this.cls = 'f-struct-is-subgrid ';
        _this.lang = "";
        _this.size = {};
        _this.enabledLanguageList = [];
        _this.tabsToolbarStates = new BehaviorSubject({});
        _this.tabsToolbarVisibleStates = new BehaviorSubject({});
        _this.dataGrid_pluslineNumberTitle = _this.langService.transform("DataGrid/dataGrid_plus/lineNumberTitle", _this.lang, "");
        _this.lang = localStorage.getItem('languageCode') || "zh-CHS";
        _this.viewModel.verifycationChanged.subscribe(function (verifyInformations) {
            _this.focusInvalidService.focusGridCell(verifyInformations, _this.dataGrid_plusDataGrid);
        });
        if (_this.frmI18nSettingService) {
            var i18nSetting = _this.frmI18nSettingService.getSetting();
            if (i18nSetting && i18nSetting.languages && i18nSetting.languages.length > 0) {
                i18nSetting.languages.forEach(function (item) {
                    _this.enabledLanguageList.push({
                        code: item.code,
                        name: item.name
                    });
                });
            }
            else {
                console.warn("get current enable languages is null. if this occurs,please ensure the form into the framework.");
                _this.enabledLanguageList.push({ "code": "en", "name": "English" });
                _this.enabledLanguageList.push({ "code": "zh-CHS", "name": "中文简体" });
            }
        }
        return _this;
    }
    PlusComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.keybindingService) {
            this.viewModel.keybindingMap.forEach(function (keyBinding, method) {
                _this.keybindingService.register(keyBinding, function () {
                    return _this.viewModel[method]();
                });
            });
        }
        this.dataGrid_plusColumns = [
            [
                {
                    id: 'fileInfo_FileInfo_Attachment_beda48ec_0lx6',
                    field: 'fileInfo.fileInfo_Attachment',
                    width: 120,
                    title: this.langService.transform("fileInfo_FileInfo_Attachment_beda48ec_0lx6", this.lang, "附件Id"),
                    dataType: 'string',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.TEXTBOX,
                        options: { "id": "fileInfo_FileInfo_Attachment_beda48ec_esnw", "title": "附件Id", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.TEXTBOX", "isPassword": false, "maxLength": 36 }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: {}
                },
                {
                    id: 'fileInfo_FileInfo_FileName_fb0c4b5e_h66o',
                    field: 'fileInfo.fileInfo_FileName',
                    width: 120,
                    title: this.langService.transform("fileInfo_FileInfo_FileName_fb0c4b5e_h66o", this.lang, "附件名称"),
                    dataType: 'string',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.TEXTBOX,
                        options: { "id": "fileInfo_FileInfo_FileName_fb0c4b5e_zlxk", "title": "附件名称", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.TEXTBOX", "isPassword": false, "maxLength": 36 }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: {}
                },
                {
                    id: 'fileInfo_FileInfo_FileSize_bed6f51d_v9nr',
                    field: 'fileInfo.fileInfo_FileSize',
                    width: 120,
                    title: this.langService.transform("fileInfo_FileInfo_FileSize_bed6f51d_v9nr", this.lang, "附件大小"),
                    dataType: 'number',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.NUMBERBOX,
                        options: { "id": "fileInfo_FileInfo_FileSize_bed6f51d_bamd", "title": "附件大小", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.NUMBERBOX", "precision": 2, "step": 1, "canNull": true, "bigNumber": false, "showButton": true, "showZero": true }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: { "type": "number", "options": { "precision": 2, "thousand": ",", "decimal": "." } }
                },
                {
                    id: 'fileInfo_FileInfo_FileCreate_3e128aef_kbsh',
                    field: 'fileInfo.fileInfo_FileCreate',
                    width: 120,
                    title: this.langService.transform("fileInfo_FileInfo_FileCreate_3e128aef_kbsh", this.lang, "附件上传时间"),
                    dataType: 'datetime',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.DATEPICKER,
                        options: { "id": "fileInfo_FileInfo_FileCreate_3e128aef_717z", "title": "附件上传时间", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.DATEPICKER", "dateRange": false, "showTime": true, "showType": 1, "dateFormat": "yyyy-MM-dd HH:mm:ss", "returnFormat": "yyyy-MM-dd HH:mm:ss", "placeholder": "", "showWeekNumbers": false, "dateRangeDatesDelimiter": "~", "editable": true, "linkedLabelEnabled": false, "linkedLabelClick": "", "hourStep": 1, "minuteStep": 1, "secondStep": 1, "firstDayOfWeek": "mo" }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: { "type": "datetime", "options": { "format": "yyyy-MM-dd HH:mm:ss" } }
                }
            ]
        ];
        this.viewModel.dataGrid_plusColumns = this.dataGrid_plusColumns;
        this.viewModel.dataGridColumnsName = "dataGrid_plusColumns";
        this.onFormLoad();
    };
    PlusComponent.prototype.ngAfterViewInit = function () {
    };
    PlusComponent.prototype.ngOnDestroy = function () {
        // 增加表单的自我销毁
        this.context.dispose && this.context.dispose();
        this.context = null;
        this.subscription = null;
        this.declaration = null;
        this.wizardSer = null;
        this.keybindingService = null;
        this.langService = null;
        this.route = null;
        this.router = null;
        this.rootElement = null;
        this.localizationService = null;
        this.frmI18nSettingService = null;
        this.focusInvalidService = null;
        this.farrisGridUtils = null;
        this.sanitizer = null;
        this.injector = null;
        this.enabledLanguageList = [];
    };
    PlusComponent.prototype.handleSizeChange = function (size) {
        this.size = size;
    };
    PlusComponent.prototype.onFormLoad = function () {
    };
    tslib_1.__decorate([
        ViewChild('dataGrid_plusDataGrid'),
        tslib_1.__metadata("design:type", DatagridComponent)
    ], PlusComponent.prototype, "dataGrid_plusDataGrid", void 0);
    tslib_1.__decorate([
        HostBinding('class'),
        tslib_1.__metadata("design:type", Object)
    ], PlusComponent.prototype, "cls", void 0);
    PlusComponent = tslib_1.__decorate([
        Component({
            selector: 'app-pluscomponent',
            templateUrl: './pluscomponent.html',
            styleUrls: ['./pluscomponent.scss'],
            providers: [
                FARRIS_DEVKIT_FRAME_PROVIDERS,
                FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS,
                { provide: FRAME_ID, useValue: 'plus-component' },
                { provide: BindingData, useClass: BindingData },
                { provide: Repository, useExisting: SORepository },
                LangService,
                { provide: NAMESPACE, useValue: '' },
                { provide: ServerSideToken, useClass: BefLookupRestService },
                { provide: ComboServerSideToken, useClass: DefaultComboHttpService },
                { provide: GRID_SETTINGS_HTTP, useClass: BefLookupRestService },
                { provide: Form, useClass: PlusComponentViewmodelForm },
                { provide: UIState, useClass: PlusComponentViewmodelUIState },
                { provide: ViewModel, useClass: PlusComponentViewmodel },
                { provide: EXCEPTION_HANDLER, useValue: null },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: plusAddItem1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: plusRemoveItem1Handler, multi: true },
            ]
        }),
        tslib_1.__metadata("design:paramtypes", [WizardService,
            KeybindingService,
            LangService,
            ActivatedRoute,
            Router,
            ElementRef,
            LocalizationService,
            FrmI18nSettingService,
            FocusInvalidService,
            CommonUtils,
            DomSanitizer,
            Injector])
    ], PlusComponent);
    return PlusComponent;
}(FrameComponent));
export { PlusComponent };
