
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '订单明细',
    enableValidate: true
})

@Injectable()
export class OrderitemComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'goods.goods_GoodsName',
        name: "{{goods_Goods_GoodsName_cd37eccb_m6h9}}",
        binding: 'goods.goods_GoodsName',
        updateOn: 'blur',
        defaultI18nValue: '商品名称',
        validRules: [
            {
                type: 'required',
                constraints: [true],
            }
        ]
    })
    goods_Goods_GoodsName: FormControl;

    @NgFormControl({
        id: 'goods.goods_Specification',
        name: "{{goods_Goods_Specification_a9d828f8_of7o}}",
        binding: 'goods.goods_Specification',
        updateOn: 'blur',
        defaultI18nValue: '规格型号',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    goods_Goods_Specification: FormControl;

    @NgFormControl({
        id: 'quality',
        name: "{{quality_aad2548f_ijrt}}",
        binding: 'quality',
        updateOn: 'blur',
        defaultI18nValue: '数量',
        validRules: [
            {
                type: 'maxValue',
                constraints: [1.7976931348623157e+308],
            },
            {
                type: 'minValue',
                constraints: [-1.7976931348623157e+308],
            }
        ]
    })
    quality: FormControl;

    @NgFormControl({
        id: 'price',
        name: "{{price_1a57e03c_wmqb}}",
        binding: 'price',
        updateOn: 'blur',
        defaultI18nValue: '标准单价',
        validRules: [
            {
                type: 'maxValue',
                constraints: [1.7976931348623157e+308],
            },
            {
                type: 'minValue',
                constraints: [-1.7976931348623157e+308],
            }
        ]
    })
    price: FormControl;

    @NgFormControl({
        id: 'actualPrice',
        name: "{{actualPrice_ffcf39b2_qt08}}",
        binding: 'actualPrice',
        updateOn: 'blur',
        defaultI18nValue: '实际单价',
        validRules: [
            {
                type: 'maxValue',
                constraints: [1.7976931348623157e+308],
            },
            {
                type: 'minValue',
                constraints: [-1.7976931348623157e+308],
            }
        ]
    })
    actualPrice: FormControl;

    @NgFormControl({
        id: 'discountType',
        name: "{{discountType_c9be5f52_qw4r}}",
        binding: 'discountType',
        updateOn: 'change',
        defaultI18nValue: '折扣类型',
    })
    discountType: FormControl;

    @NgFormControl({
        id: 'discount',
        name: "{{discount_92ee9f2f_or2b}}",
        binding: 'discount',
        updateOn: 'blur',
        defaultI18nValue: '折扣',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    discount: FormControl;

    @NgFormControl({
        id: 'amount',
        name: "{{amount_9b7b1a84_vfjl}}",
        binding: 'amount',
        updateOn: 'blur',
        defaultI18nValue: '结算金额',
        validRules: [
            {
                type: 'maxValue',
                constraints: [1.7976931348623157e+308],
            },
            {
                type: 'minValue',
                constraints: [-1.7976931348623157e+308],
            }
        ]
    })
    amount: FormControl;

}