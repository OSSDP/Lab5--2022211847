import * as tslib_1 from "tslib";
import { Entity, NgField, NgObject, EntityList, NgList, NgEntity } from '@farris/devkit';
import { OrderItemEntity } from './orderitementity';
import { PlusEntity } from './plusentity';
import { BillStateDf94Entity } from './billstatedf94entity';
import { ProcessInstanceEcEdEntity } from './processinstanceecedentity';
import { SysOrg17e7Entity } from './sysorg17e7entity';
import { SysOrg5ffbEntity } from './sysorg5ffbentity';
var SOEntity = /** @class */ (function (_super) {
    tslib_1.__extends(SOEntity, _super);
    function SOEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SOEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], SOEntity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'OrderCode',
            dataField: 'orderCode',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'OrderCode',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SOEntity.prototype, "orderCode", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'OrderTime',
            dataField: 'orderTime',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'OrderTime',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [30],
                    message: '最大长度为30',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SOEntity.prototype, "orderTime", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'PayMethod',
            dataField: 'payMethod',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'Cash',
            path: 'PayMethod',
        }),
        tslib_1.__metadata("design:type", Object)
    ], SOEntity.prototype, "payMethod", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'OrderType',
            dataField: 'orderType',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'OrderType',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [20],
                    message: '最大长度为20',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SOEntity.prototype, "orderType", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Telephone',
            dataField: 'telephone',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Telephone',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [20],
                    message: '最大长度为20',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SOEntity.prototype, "telephone", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'OrderState',
            dataField: 'orderState',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'Unshipped',
            path: 'OrderState',
        }),
        tslib_1.__metadata("design:type", Object)
    ], SOEntity.prototype, "orderState", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Remark',
            dataField: 'remark',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Remark',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [100],
                    message: '最大长度为100',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SOEntity.prototype, "remark", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'TotalPrice',
            dataField: 'totalPrice',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'TotalPrice',
        }),
        tslib_1.__metadata("design:type", Object)
    ], SOEntity.prototype, "totalPrice", void 0);
    tslib_1.__decorate([
        NgList({
            dataField: 'orderItems',
            originalDataField: '',
            type: OrderItemEntity
        }),
        tslib_1.__metadata("design:type", EntityList)
    ], SOEntity.prototype, "orderItems", void 0);
    tslib_1.__decorate([
        NgList({
            dataField: 'pluss',
            originalDataField: '',
            type: PlusEntity
        }),
        tslib_1.__metadata("design:type", EntityList)
    ], SOEntity.prototype, "pluss", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'billStatus',
            originalDataField: 'BillStatus',
            type: BillStateDf94Entity
        }),
        tslib_1.__metadata("design:type", BillStateDf94Entity)
    ], SOEntity.prototype, "billStatus", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'processInstance',
            originalDataField: 'ProcessInstance',
            type: ProcessInstanceEcEdEntity
        }),
        tslib_1.__metadata("design:type", ProcessInstanceEcEdEntity)
    ], SOEntity.prototype, "processInstance", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'merchant',
            originalDataField: 'Merchant',
            type: SysOrg17e7Entity
        }),
        tslib_1.__metadata("design:type", SysOrg17e7Entity)
    ], SOEntity.prototype, "merchant", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'orderPerson',
            originalDataField: 'OrderPerson',
            type: SysOrg5ffbEntity
        }),
        tslib_1.__metadata("design:type", SysOrg5ffbEntity)
    ], SOEntity.prototype, "orderPerson", void 0);
    SOEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "SO",
            nodeCode: "sos"
        })
    ], SOEntity);
    return SOEntity;
}(Entity));
export { SOEntity };
