package com.inspur.gs.scm.om.so.so.back.bizactions;
import com.inspur.edp.cef.api.message.*;
import com.inspur.edp.bef.api.action.determination.*;
import com.inspur.edp.bef.api.action.validation.*;
import com.inspur.edp.cef.entity.changeset.*;
import com.inspur.edp.bef.api.be.*;
import com.inspur.edp.bef.api.action.VoidActionResult;
import com.inspur.edp.bef.spi.action.AbstractManagerAction;

public class SOSendGoodsMgrAction extends AbstractManagerAction<VoidActionResult> {
	private String id;
	private String snedstate;
	public SOSendGoodsMgrAction(IBEManagerContext managerContext, String id, String snedstate) {
		super(managerContext);
		this.id = id;
		this.snedstate = snedstate;
	}
	@Override
	public  void execute() {
	}
	private IBusinessEntity getEntity(String dataId) {
		return (IBusinessEntity)super.getBEManagerContext().getEntity(dataId);
	}	private IBEService getMgr() {
		return (IBEService)super.getBEManagerContext().getBEManager();
	}
}